# Changelog

All notable changes to this project will be documented in this file.

## [1.3.8] - 2022-09-15

### Features

- [Public] updated TM version
- [Public] fixed `stepRouting` widget

