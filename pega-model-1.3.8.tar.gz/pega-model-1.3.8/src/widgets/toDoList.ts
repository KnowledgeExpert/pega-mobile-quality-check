// Copyright 2021 Knowledge Expert SA
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

import {pega} from "../pega";
import {I, Selector} from 'test-maker';

export class ToDoList { //Pega 8.5 and higher

    public container: string;
    readonly goButton = pega.buttonByDataTestId(`20190208081744082718727`);
    readonly goButtonSelector = `//button[@data-test-id="20190208081744082718727"]`;
    public tasksNumber: number;
    public taskName: string;
    public supportingText: string;
    public dueDateMessage: string;

    constructor(args?: { taskName?: string, caseName?: string, operatorName?: string }) {
        if (args) {
            if (args.taskName && args.operatorName && !args.caseName) {
                this.container = `//i[@title="${args.operatorName}"]//ancestor::div[@pyclassname="Assign-Worklist"]//ancestor::span[@data-test-id="20190208081744082517799" and contains(text(), "${args.taskName}")]//ancestor::div[@pyclassname="Assign-Worklist"]`; //toDo check if can be improved
            } else if (args.taskName && !args.operatorName && !args.caseName) {
                this.container = `//span[@data-test-id="20190208081744082517799" and contains(text(), "${args.taskName}") and not(contains(@class, "supporting_text"))]//ancestor::div[@pyclassname="Assign-Worklist"]`;
            } else if (args.taskName && !args.operatorName && args.caseName) {
                this.container = `//span[@data-test-id="20190208081744082517799" and contains(text(), "${args.taskName}") and not(contains(@class, "supporting_text"))]//ancestor::div[@pyclassname="Assign-Worklist"]//span[@data-test-id="20190208081744082517799" and contains(text(), "${args.caseName}") and contains(@class, "supporting_text")]//ancestor::div[@pyclassname="Assign-Worklist"]`;
            } else if (!args.taskName && !args.operatorName && args.caseName) {
                this.container = `//span[@data-test-id="20190208081744082517799" and contains(text(), "${args.caseName}") and contains(@class, "supporting_text")]//ancestor::div[@pyclassname="Assign-Worklist"]`;
            } else if (!args.taskName && args.operatorName && args.caseName) {
                this.container = `//i[@title="${args.operatorName}"]//ancestor::div[@pyclassname="Assign-Worklist"]//ancestor::span[@data-test-id="20190208081744082517799" and contains(text(), "${args.caseName}") and contains(@class, "supporting_text")]//ancestor::div[@pyclassname="Assign-Worklist"]`; //toDo check if can be improved
            } else if (args.operatorName && !args.taskName && !args.caseName) {
                this.container = `//i[@title="${args.operatorName}"]//ancestor::div[@pyclassname="Assign-Worklist"]`;
            }
        } else if (!args) {
            this.container = `//div[@pyclassname="Assign-Worklist"]`;
            console.warn(`The task name or operator was not specified, the very first task will be selected`);
        }
    }

    async openTask(): Promise<void> {
        await I.click(`${this.container}${this.goButtonSelector}`);
    }

    async openFirstTask(): Promise<void> {
        await this.goButton.click();
    }

    async openTaskByIndex(index: number): Promise<void> {
        await I.click(Selector(this.goButtonSelector).filterVisible().nth(index));
    }

    async assertAtLeastOneTaskIsVisible(): Promise<void> {
        await this.goButton.shouldBeVisible();
    }

    async assertTasksAreNotVisible(): Promise<void> {
        await this.goButton.shouldNotBeVisible();
    }

    async tasksDontExist(): Promise<void> {
        await this.goButton.shouldNotExist();
    }

    async assertTaskByTextOrOperatorNameIsVisible(): Promise<void> {
        await I.expectSelector(this.container).toBeVisible();
    }

    async isTaskExists(): Promise<boolean> {
        return await Selector(this.container).exists;
    }

    async isTaskVisible(): Promise<boolean> {
        return await Selector(this.container).exists && await Selector(this.container).visible;
    }

    async assertTaskByTextOrOperatorNameIsNotVisible(): Promise<void> {
        await I.expectSelector(this.container).not.toBeVisible();
    }

    async assertNumberOfVisibleTasks(count: number): Promise<void> {
        await I.expect(Selector(`${this.container}${this.goButtonSelector}`).filterVisible().count).toEqual(count);
    }

    async getNumberOfVisibleTasks() {
        this.tasksNumber = await Selector(`${this.container}${this.goButtonSelector}`).filterVisible().count;
        return this.tasksNumber;
    }

    async assertNumberOfVisibleTasksIsMoreThan(count: number): Promise<void> {
        await I.expect(Selector(`${this.container}${this.goButtonSelector}`).filterVisible().count).toBeGreaterThan(count);
    }

    async viewAll(): Promise<void> {
        await pega.buttonByDataTestId(`2015110410023706663712`).hoverAndClick();
    }

    async viewAllIfVisible(): Promise<void> {
        if (await Selector(`[data-test-id="2015110410023706663712"]`).exists && await Selector(`[data-test-id="2015110410023706663712"]`).visible)
            await pega.buttonByDataTestId(`2015110410023706663712`).hoverAndClick();
    }

    async viewLess(): Promise<void> {
        await pega.buttonByDataTestId(`2019031407413508163787`).hoverAndClick();
    }

    async assertTaskHasNameByIndex(taskName: string, index: number) {
        await I.expect(Selector(`//div[@pyclassname="Assign-Worklist"]//div[@data-test-id="201808170838240368667"]//span[@data-test-id="20190208081744082517799"]`).filterVisible().nth(index).innerText).toEqual(taskName);
    }

    async assertTaskHasSupportingTextByIndex(supportingText: string, index: number) {
        await I.expect(Selector(`//div[@pyclassname="Assign-Worklist"]//div[@data-test-id="201808170838240368923"]//span[@data-test-id="20190208081744082517799"]`).filterVisible().nth(index).innerText).toEqual(supportingText);
    }

    async assertTaskHasDueDateMessageByIndex(dueDateMessage: string, index: number) {
        if (dueDateMessage.includes('Due')) {
            dueDateMessage = dueDateMessage.substring(4);
        }
        await I.expect(Selector(`//div[@pyclassname="Assign-Worklist"]//div[@data-test-id="201808170838240368923"]//span[@data-test-id="20190208081953009346428"]`).filterVisible().nth(index).innerText).toContain(dueDateMessage);
    }

    async getTaskNameByIndex(index: number) {
        this.taskName = await Selector(`//div[@pyclassname="Assign-Worklist"]//div[@data-test-id="201808170838240368667"]//span[@data-test-id="20190208081744082517799"]`).filterVisible().nth(index).innerText;
        return this.taskName;
    }

    async getTaskSupportingTextByIndex(index: number) {
        this.supportingText = await Selector(`//div[@pyclassname="Assign-Worklist"]//div[@data-test-id="201808170838240368923"]//span[@data-test-id="20190208081744082517799"]`).filterVisible().nth(index).innerText;
        return this.supportingText;
    }

    async getTaskDueDateMessageByIndex(index: number) {
        this.dueDateMessage = await Selector(`//div[@pyclassname="Assign-Worklist"]//div[@data-test-id="201808170838240368923"]//span[@data-test-id="20190208081953009346428"]`).filterVisible().nth(index).innerText;
        this.dueDateMessage = 'Due ' + this.dueDateMessage;
        return this.dueDateMessage;
    }

    async waitForTheTaskToBeCreatedAndOpen(args ?: { interval?: number, timeout?: number }) {
        const options = {timeout: 2000};
        if (!await Selector(this.container, options).exists) {
            let actualInterval: number = 500, actualTimeout: number = 15000;
            if (args?.interval) {
                actualInterval = args.interval;
            }
            if (args?.timeout)
                actualTimeout = args.timeout;
            await I.waitForCondition({
                condition: async () => {
                    const options = {timeout: 500};
                    await pega.actionsMenu.selectOption('Refresh');
                    await this.viewAllIfVisible();
                    return await Selector(this.container, options).exists;
                },
                interval: actualInterval,
                timeout: actualTimeout,
                retryMessage: `Waiting for case to be created`,
            });
        }
        await this.openTask();
    }
}