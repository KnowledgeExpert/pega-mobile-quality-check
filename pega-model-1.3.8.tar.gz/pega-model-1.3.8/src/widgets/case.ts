// Copyright 2019 Knowledge Expert SA
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

import {Selector, I} from 'test-maker';
import {methodOptions, Options} from '../../helpers/options/methodOptions';
import {pega} from '../pega';
import {pegaVersion} from '../../helpers/pegaVersion';
import {logger} from 'test-maker';

export class Case {

    private pegaVersion(): number {
        pegaVersion.setVersion();
        return pegaVersion.getVersion();
    }

    private static object: Case;
    caseId: string = '';

    static create(): Case {
        if (!this.object) {
            this.object = new Case();
        }
        return this.object;
    }

    private actualOptions;

    caseIdElement() {
        let currentVersion = +this.pegaVersion();
        return currentVersion < 850 ? '[class="workarea_header_id"]' : 'span[data-test-id="20190510022618055338234"]';
    }

    async getId() {
        await  pegaVersion.setVersion();
        let actualElement: string = this.caseIdElement();
        await I.expect(Selector(actualElement).exists).toBeOk();
        await I.expect(Selector(actualElement).visible).toBeOk();
        this.caseId = await Selector(actualElement).innerText;
        if (this.pegaVersion() < 850) {
            this.caseId = this.caseId.substring(1, this.caseId.length - 1);
        }
        return this.caseId;
    }

    async assertCaseId(caseId: string, options?: { timeout?: number, assertionTimeout?: number, interval?: number, retries?: number }) {
        this.actualOptions = methodOptions.setOptions(options);
        await I.expect(Selector(this.caseIdElement(), this.actualOptions).innerText, {
            timeout: this.actualOptions.assertionTimeout,
            interval: this.actualOptions.interval,
            retries: this.actualOptions.retries
        }).toContain(caseId);
    }

    async consoleLogId() {
        await this.getId();
        let caseId: string = this.caseId;
        await logger.log(caseId);
    }

    async findAndOpenCase(caseNumber: string | number, isIframeAvailable: boolean, timeToHardWait: number= 1, options?: { timeout: number, interval?: number, retries?: number }) {
        this.actualOptions = methodOptions.setOptions(options);
        await I.waitForSelectorToBeVisible(Selector(`[data-test-id="2015030515570700545405"]`,
            this.actualOptions));
        await I.fillField(Selector('[data-test-id="2015030515570700545405"]', this.actualOptions), caseNumber);
        await I.pressEnterKey();

        await I.wait(timeToHardWait)
        if (isIframeAvailable) {
            await pega.frame.switchToWorkAreaIframe(timeToHardWait)
            await I.wait(timeToHardWait);
        }
        await I.click('[data-test-id="201609091025020567152987"]')
            .wait(timeToHardWait);
        if (isIframeAvailable) {
            await pega.frame.switchToWorkAreaIframe(timeToHardWait);
        }
        await I.click(Selector('[data-test-id="20161017110917023176385"]', this.actualOptions));
    }

    async shouldHaveName(caseName: string, options?: { timeout?: number, assertionTimeout?: number, interval?: number, retries?: number }) {
        this.actualOptions = methodOptions.setOptions(options);
        let titleElement: string;
        await  pegaVersion.setVersion();
        this.pegaVersion() < 850 ? titleElement = '[class="workarea_header_titles"]' : '//div[@data-test-id="201806191352120508640_header"]//div[@class="header-content"]/h1[@class="header-title"]'
        await I.expect(Selector(titleElement, this.actualOptions).innerText, {
            timeout: this.actualOptions.assertionTimeout,
            interval: this.actualOptions.interval,
            retries: this.actualOptions.retries
        }).toEqual(caseName);
    }
}

