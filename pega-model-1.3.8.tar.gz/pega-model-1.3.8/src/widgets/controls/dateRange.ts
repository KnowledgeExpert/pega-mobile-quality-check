// Copyright 2021 Knowledge Expert SA
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

import {I, Selector} from "test-maker";
import {controlsCommonActions} from './controlsCommonActions';

export class DateRange {

    public readonly dataTestId: string;

    constructor(dataTestId: string) {
        this.dataTestId = dataTestId;
    }

    inputElements(): string { //hidden start and end date input elements
        return `//input[contains (@data-test-id, "${this.dataTestId}")][@data-ctl='["DateRange"]']`;
    }

    inputElement(dateType: string): string {
        return `//input[@data-test-id=\"${this.dataTestId}_${dateType}\"]`;
    }

    spanElement(dateType: string): string {
        return `${this.spanElement(dateType)}/following-sibling::span`;
    }

    parentSpan(): string { //common for 2 dateRange elements
        return `//input[contains (@data-test-id, "${this.dataTestId}")][@data-ctl='["DateRange"]']/parent::span`;
    }

    // @ts-ignore
    async set(startDate: string, endDate: string) {
        await I.eval(({dataTestId, startDate, endDate}) => {

            var startInput = document.evaluate(`//input[@data-test-id=\"${dataTestId}_startDate\"]`, document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue;
            // @ts-ignore
            startInput.value = startDate;
            var endInput = document.evaluate(`//input[@data-test-id=\"${dataTestId}_endDate\"]`, document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue;
            // @ts-ignore
            endInput.value = endDate;
            var startSpan = document.evaluate(`//input[@data-test-id=\"${dataTestId}_startDate\"]/following-sibling::span`, document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue;
            // @ts-ignore
            startSpan.innerText = startDate;
            var endSpan = document.evaluate(`//input[@data-test-id=\"${dataTestId}_endDate\"]/following-sibling::span`, document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue;
            // @ts-ignore
            endSpan.innerText = endDate;
        }, {dataTestId: this.dataTestId, startDate: startDate, endDate: endDate});
    };

    async shouldBeVisible() {
        await I.expectSelector(this.parentSpan()).toBeVisible();
    }

    async shouldNotBeVisible() {
        await I.expectSelector(this.parentSpan()).toBeVisible();
    }

    async shouldHaveValue(dateType: string, value: string) {
        await I.expect(Selector(this.inputElement(dateType)).value).toEqual(value);
    }

    async shouldNotHaveValue(dateType: string, value: string) {
        await I.expect(Selector(this.inputElement(dateType)).value).not.toEqual(value);
    }

    async shouldHaveInnerText(dateType: string, value: string) {
        await I.expect(Selector(this.spanElement(dateType)).innerText).toEqual(value);
    }

    async shouldNotHaveInnerText(dateType: string, value: string) {
        await I.expect(Selector(this.spanElement(dateType)).innerText).not.toEqual(value);
    }

    async click(dateType: string) {
        await I.click(this.spanElement(dateType));
    }

    async isVisible(options?: { filterByVisibility?: boolean, index?: number, timeout?: number, assertionTimeout?: number, interval?: number, retries?: number }) {
        return await controlsCommonActions.isVisible(this.parentSpan(), options);
    }

    async isExists(options?: { index?: number, timeout?: number, assertionTimeout?: number, interval?: number, retries?: number }) {
        return await controlsCommonActions.isExists(this.parentSpan(), options);
    }
}


