// Copyright 2019 Knowledge Expert SA
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

import {I, Selector} from 'test-maker';
import {ButtonsActions} from '../buttons/buttonsActions';
import {TableCheckbox} from './tableControls/tableCheckbox';
import {methodOptions, Options} from '../../../../helpers/options/methodOptions';
import {controlsCommonActions} from '../controlsCommonActions';

export class Cell {

    public readonly element: string;
    readonly index: number;

    constructor(container: string, index = 0) {
        this.element = container;
        this.index = index
    }

    private actualOptions;

    async waitUntilVisibility(options?: { timeout?: number, interval?: number, retries?: number }) {
        await controlsCommonActions.waitUntilVisibility(this.element, options);
    }

    async waitUntilVisibilityByText(text: string, options?: { timeout?: number, interval?: number, retries?: number }) {
        await controlsCommonActions.waitUntilVisibilityByText(this.element, text, options);
    }

    async waitUntilVisibilityByAttribute(attributeName: string, attributeValue?: string,
                                         options?: { timeout?: number, interval?: number, retries?: number }) {
        await controlsCommonActions.waitUntilVisibilityByAttribute(this.element, attributeName, attributeValue, options);
    }

    async waitUntilVisibilityByIndex(index: number, options?: { timeout?: number, interval?: number, retries?: number }) {
        await controlsCommonActions.waitUntilVisibilityByIndex(this.element, index, options);
    }

    async waitUntilCollectionOfElementsSizeIsGreaterOrEqual(expectedSize: number, options?: { timeout?: number, interval?: number, retries?: number }) {
        await controlsCommonActions.waitUntilCollectionOfElementsSizeIsGreaterOrEqual(this.element, expectedSize, options);
    }

    async waitUntilCollectionOfElementsSizeIsLessThan(expectedSize: number, options?: { timeout?: number, interval?: number, retries?: number }) {
        await controlsCommonActions.waitUntilCollectionOfElementsSizeIsLessThan(this.element, expectedSize, options);
    }

    async waitUntilInvisibility(options?: { timeout?: number, interval?: number, retries?: number }) {
        await controlsCommonActions.waitUntilInvisibility(this.element, options);
    }

    async waitUntilInvisibilityByIndex(index: number, options?: { timeout?: number, interval?: number, retries?: number }) {
        await controlsCommonActions.waitUntilInvisibilityByIndex(this.element, index, options);
    }

    async waitUntilElementExists(options?: { timeout?: number, interval?: number, retries?: number }) {
        await controlsCommonActions.waitUntilElementExists(this.element, options);
    }

    async waitUntilElementNotExist(options?: { timeout?: number, interval?: number, retries?: number }) {
        await controlsCommonActions.waitUntilElementNotExist(this.element, options);
    }

    async waitForSelectActionabilityCheck(checks: []) {
        await I.waitForSelectActionabilityCheck(this.element, checks);
    }

    async hover(options?: { timeout?: number, interval?: number, retries?: number }) {
        this.actualOptions = methodOptions.setOptions(options);
        await I.hover(Selector(this.element, this.actualOptions).filterVisible().nth(this.index));
    }

    async click(options?: { timeout?: number, interval?: number, retries?: number }) {
        this.actualOptions = methodOptions.setOptions(options);
        await I.click(Selector(this.element, this.actualOptions).filterVisible().nth(this.index));
    }

    async focus(options?: { timeout?: number, interval?: number, retries?: number }) {
        this.actualOptions = methodOptions.setOptions(options);
        await I.focus(Selector(this.element, this.actualOptions).filterVisible().nth(this.index));
    }

    async clickTheLink(options?: { timeout?: number, interval?: number, retries?: number }) {
        this.actualOptions = methodOptions.setOptions(options);
        await I.click(Selector(`${this.element}//a`, this.actualOptions).filterVisible().nth(this.index));
    }

    icon() {
        return `${this.element}//i`;
    }

    button(): ButtonsActions {
        return new ButtonsActions(`${this.element}//button`, this.index);
    }

    async set(value: string | number, options?: { timeout?: number, interval?: number, retries?: number }) {
        this.actualOptions = methodOptions.setOptions(options);
        await I.click(Selector(this.element, this.actualOptions).filterVisible().nth(this.index))
            .fillField(Selector(`${this.element}//input`, this.actualOptions).filterVisible().nth(this.index), value);
    }

    async paste(value: string | number, options?: { timeout?: number, interval?: number, retries?: number }) {
        this.actualOptions = methodOptions.setOptions(options);
        await I.click(Selector(this.element, this.actualOptions).filterVisible().nth(this.index))
            .fillField(Selector(`${this.element}//input`, this.actualOptions).filterVisible().nth(this.index), value, {paste:true});
    }

    async shouldHaveText(text: string | number, options?: { timeout?: number, assertionTimeout?: number, interval?: number, retries?: number, isCaseSensitive?: boolean }) {
        this.actualOptions = methodOptions.setOptions(options);
        text = text + "";
        if (!this.actualOptions.isCaseSensitive) {
            await I.expect(async () => {
                return (await Selector(`${this.element}//input`, this.actualOptions).filterVisible().nth(this.index)
                    .innerText).toLowerCase();
            }, {
                timeout: this.actualOptions.assertionTimeout,
                interval: this.actualOptions.interval,
                retries: this.actualOptions.retries
            }).toContain(text.toLowerCase());
        } else {
            await I.expect(Selector(`${this.element}//input`, this.actualOptions).filterVisible().nth(this.index).innerText, {
                timeout: this.actualOptions.assertionTimeout,
                interval: this.actualOptions.interval,
                retries: this.actualOptions.retries
            }).toContain(text);
        }
    }

    async shouldNotHaveText(text: string | number, options?: { timeout?: number, assertionTimeout?: number, interval?: number, retries?: number, isCaseSensitive?: boolean }) {
        this.actualOptions = methodOptions.setOptions(options);
        text = text + "";
        if (!this.actualOptions.isCaseSensitive) {
            await I.expect(async () => {
                return (await Selector(`${this.element}//input`, this.actualOptions).filterVisible().nth(this.index)
                    .innerText).toLowerCase();
            }, {
                timeout: this.actualOptions.assertionTimeout,
                interval: this.actualOptions.interval,
                retries: this.actualOptions.retries
            }).not.toContain(text.toLowerCase());
        } else {
            await I.expect(await Selector(`${this.element}//input`, this.actualOptions).filterVisible().nth(this.index).innerText, {
                timeout: this.actualOptions.assertionTimeout,
                interval: this.actualOptions.interval,
                retries: this.actualOptions.retries
            }).not.toContain(text);
        }
    }

    async shouldHaveReadonlyText(text: string | number, innerType: string = 'span', options?: { timeout?: number, assertionTimeout?: number, interval?: number, retries?: number, isCaseSensitive?: boolean }) {
        this.actualOptions = methodOptions.setOptions(options);
        text = text + "";
        if (!this.actualOptions.isCaseSensitive) {
            await I.expect(async () => {
                return (await Selector(`${this.element}//${innerType}`, this.actualOptions).filterVisible().nth(this.index).innerText).toLowerCase();
            }, {
                timeout: this.actualOptions.assertionTimeout,
                interval: this.actualOptions.interval,
                retries: this.actualOptions.retries
            }).toContain(text.toLowerCase());
        } else {
            await I.expect(Selector(`${this.element}//${innerType}`, this.actualOptions).filterVisible().nth(this.index).innerText, {
                timeout: this.actualOptions.assertionTimeout,
                interval: this.actualOptions.interval,
                retries: this.actualOptions.retries
            }).toContain(text);
        }
    }
    async shouldHaveReadonlyTextByDataTestId(text: string | number, dataTestId: string, innerType: string = 'span', options?: { timeout?: number, assertionTimeout?: number, interval?: number, retries?: number, isCaseSensitive?: boolean }) {
        this.actualOptions = methodOptions.setOptions(options);
        text = text + "";
        if (!this.actualOptions.isCaseSensitive) {
            await I.expect(async () => {
                return (await Selector(`${this.element}//${innerType}[@data-test-id="${dataTestId}"]`, this.actualOptions).filterVisible().nth(this.index).innerText).toLowerCase();
            }, {
                timeout: this.actualOptions.assertionTimeout,
                interval: this.actualOptions.interval,
                retries: this.actualOptions.retries
            }).toContain(text.toLowerCase());
        } else {
            await I.expect(Selector(`${this.element}//${innerType}[@data-test-id="${dataTestId}"]`, this.actualOptions).filterVisible().nth(this.index).innerText, {
                timeout: this.actualOptions.assertionTimeout,
                interval: this.actualOptions.interval,
                retries: this.actualOptions.retries
            }).toContain(text);
        }
    }

    async shouldNotHaveReadonlyText(text: string | number, innerType: string = 'span', options?: { timeout?: number, assertionTimeout?: number, interval?: number, retries?: number, isCaseSensitive?: boolean }) {
        text = text + "";
        this.actualOptions = methodOptions.setOptions(options);
        if (!this.actualOptions.isCaseSensitive) {
            await I.expect(async () => {
                return (await Selector(`${this.element}//${innerType}`, this.actualOptions).filterVisible().nth(this.index).innerText).toLowerCase();
            }, {
                timeout: this.actualOptions.assertionTimeout,
                interval: this.actualOptions.interval,
                retries: this.actualOptions.retries
            }).not.toContain(text.toLowerCase());
        } else {
            await I.expect(Selector(`${this.element}//${innerType}`, this.actualOptions).filterVisible().nth(this.index).innerText, {
                timeout: this.actualOptions.assertionTimeout,
                interval: this.actualOptions.interval,
                retries: this.actualOptions.retries
            }).not.toContain(text);
        }
    }

    async shouldNotHaveReadonlyTextByDataTestId(text: string | number, dataTestId: string, innerType: string = 'span', options?: { timeout?: number, assertionTimeout?: number, interval?: number, retries?: number, isCaseSensitive?: boolean }) {
        text = text + "";
        this.actualOptions = methodOptions.setOptions(options);
        if (!this.actualOptions.isCaseSensitive) {
            await I.expect(async () => {
                return (await Selector(`${this.element}//${innerType}[@data-test-id="${dataTestId}"]`, this.actualOptions).filterVisible().nth(this.index).innerText).toLowerCase();
            }, {
                timeout: this.actualOptions.assertionTimeout,
                interval: this.actualOptions.interval,
                retries: this.actualOptions.retries
            }).not.toContain(text.toLowerCase());
        } else {
            await I.expect(Selector(`${this.element}//${innerType}[@data-test-id="${dataTestId}"]`, this.actualOptions).filterVisible().nth(this.index).innerText, {
                timeout: this.actualOptions.assertionTimeout,
                interval: this.actualOptions.interval,
                retries: this.actualOptions.retries
            }).not.toContain(text);
        }
    }

    async shouldNotBeBlank(innerType: string = 'span', options?: { timeout?: number, assertionTimeout?: number, interval?: number, retries?: number }) {
        this.actualOptions = methodOptions.setOptions(options);
            await I.expect(Selector(`${this.element}//${innerType}`, this.actualOptions).filterVisible().nth(this.index).innerText, {
                timeout: this.actualOptions.assertionTimeout,
                interval: this.actualOptions.interval,
                retries: this.actualOptions.retries
            }).not.toEqual('');
    }

    async shouldBeBlank(innerType: string = 'span', options?: { timeout?: number, assertionTimeout?: number, interval?: number, retries?: number }) {
        this.actualOptions = methodOptions.setOptions(options);
        await I.expect(Selector(`${this.element}//${innerType}`, this.actualOptions).filterVisible().nth(this.index).innerText, {
            timeout: this.actualOptions.assertionTimeout,
            interval: this.actualOptions.interval,
            retries: this.actualOptions.retries
        }).toEqual('').or.toBeUndefined();
    }

    async shouldHaveValue(value: string | number, options?: { timeout?: number, assertionTimeout?: number, interval?: number, retries?: number, isCaseSensitive?: boolean }) {
        this.actualOptions = methodOptions.setOptions(options);
        value = value + "";
        if (!this.actualOptions.isCaseSensitive) {
            await I.expect(async () => {
                return (await Selector(`${this.element}//input`, this.actualOptions).filterVisible().nth(this.index).getAttribute('value')).toLowerCase();
            }, {
                timeout: this.actualOptions.assertionTimeout,
                interval: this.actualOptions.interval,
                retries: this.actualOptions.retries
            }).toContain(value.toLowerCase());
        } else {
            await I.expect(Selector(`${this.element}//input`, this.actualOptions).filterVisible().nth(this.index).getAttribute('value'), {
                timeout: this.actualOptions.assertionTimeout,
                interval: this.actualOptions.interval,
                retries: this.actualOptions.retries
            }).toContain(value);
        }
    }

    async shouldNotHaveValue(value: string | number, options?: { timeout?: number, assertionTimeout?: number, interval?: number, retries?: number, isCaseSensitive?: boolean }) {
        value = value + "";
        this.actualOptions = methodOptions.setOptions(options);
        if (!this.actualOptions.isCaseSensitive) {
            await I.expect(async () => {
                return (await Selector(`${this.element}//input`, this.actualOptions).filterVisible().nth(this.index).getAttribute('value')).toLowerCase();
            }, {
                timeout: this.actualOptions.assertionTimeout,
                interval: this.actualOptions.interval,
                retries: this.actualOptions.retries
            }).not.toContain(value.toLowerCase());
        } else {
            await I.expect(Selector(`${this.element}//input`, this.actualOptions).filterVisible().nth(this.index).getAttribute('value'), {
                timeout: this.actualOptions.assertionTimeout,
                interval: this.actualOptions.interval,
                retries: this.actualOptions.retries
            }).not.toContain(value);
        }
    }

    async shouldContainElementWithAttributes(attributes: {attributeName: string, attributeValue?: string, elementType?: string},
                                             options?: { timeout?: number, assertionTimeout?: number, interval?: number, retries?: number}) {
        this.actualOptions = methodOptions.setOptions(options);
        let tag, finalElement;
        attributes.elementType ? tag = attributes.elementType : tag = `*`;
        attributes.attributeValue ? finalElement = `${tag}[@${attributes.attributeName}="${attributes.attributeValue}"]` :
            finalElement = `//${tag}[@${attributes.attributeName}]`
        await I.expectSelector(Selector(`${this.element}//${finalElement}`, this.actualOptions).filterVisible().nth(this.index), {
            timeout: this.actualOptions.assertionTimeout,
            interval: this.actualOptions.interval,
            retries: this.actualOptions.retries
        }).toExist();
    }

    async shouldNotContainElementWithAttributes(attributes: {attributeName: string, attributeValue?: string, elementType?: string},
                                             options?: { timeout?: number, assertionTimeout?: number, interval?: number, retries?: number}) {
        this.actualOptions = methodOptions.setOptions(options);
        let tag, finalElement;
        attributes.elementType ? tag = attributes.elementType : tag = `*`;
        attributes.attributeValue ? finalElement = `${tag}[@${attributes.attributeName}="${attributes.attributeValue}"]` :
            finalElement = `${tag}[@${attributes.attributeName}]`
        await I.expectSelector(Selector(`${this.element}//${finalElement}`, this.actualOptions).filterVisible().nth(this.index), {
            timeout: this.actualOptions.assertionTimeout,
            interval: this.actualOptions.interval,
            retries: this.actualOptions.retries
        }).not.toExist();
    }

    async selectValueFromDropdownMenu(value: string | number, options?: { timeout?: number, assertionTimeout?: number, interval?: number, retries?: number }) {
        value = value + "";
        this.actualOptions = methodOptions.setOptions(options);
        await I.selectOption(Selector(this.element, this.actualOptions).nth(this.index), [value]);
    }

    async dropdownMenuShouldHaveValue(value: string | number, options?: { timeout?: number, assertionTimeout?: number, interval?: number, retries?: number }) {
        value = value + "";
        this.actualOptions = methodOptions.setOptions(options);
        await I.expect(Selector(`${this.element}//option[@value='${value}']`, this.actualOptions).filterVisible().nth(this.index).selected, {
            timeout: this.actualOptions.assertionTimeout,
            interval: this.actualOptions.interval,
            retries: this.actualOptions.retries
        }).toBeOk();
    }

    label() {
        return `${this.element}//label`;
    }

    switcher() {
        return `${this.element}//for`;
    }

    checkbox() { // todo: change to Checkbox
        return new TableCheckbox(this.element, this.index);
    }

    link() {
        return `${this.element}//a`;
    }

    next(name?: string) {
        if (name) {
            return new Cell(`${this.element}/following-sibling::*[@data-attribute-name='${name}']`)
        }
        return new Cell(`${this.element}/following-sibling`)
    }

    previous(name?: string) {
        if (name) {
            return new Cell(`${this.element}/preceding-sibling::*[@data-attribute-name='${name}']`)
        }
        return new Cell(`${this.element}/preceding-sibling`)
    }
}
