// Copyright 2020 Knowledge Expert SA
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// @ts-ignore
import {Selector, I, ActionabilityCheckTypes} from 'test-maker';
import {methodOptions, Options} from '../../../helpers/options/methodOptions';

export class ControlsCommonActions {

    value: string = '';
    text: string = '';
    private actualOptions;


//mouse actions
    async click(element: string, options?: { index?: number, timeout?: number, retries?: number, interval?: number }) {
        this.actualOptions = methodOptions.setOptions(options);
        await I.click(Selector(element, this.actualOptions).filterVisible());
    }

    async rightClick(element: string, options?: { index?: number, timeout?: number, retries?: number, interval?: number }) {
        this.actualOptions = methodOptions.setOptions(options);
        await I.rightClick(Selector(element, this.actualOptions).filterVisible());
    }

    async doubleClick(element: string, options?: { index?: number, timeout?: number, retries?: number, interval?: number }) {
        this.actualOptions = methodOptions.setOptions(options);
        await I.doubleClick(Selector(element, this.actualOptions).filterVisible());
    }

    async middleClick(element: string, options?: { index?: number, timeout?: number, retries?: number, interval?: number }) {
        this.actualOptions = methodOptions.setOptions(options);
        await I.middleClick(Selector(element, this.actualOptions).filterVisible());
    }

    async focus(element: string, options?: { index?: number, timeout?: number, retries?: number, interval?: number }) {
        this.actualOptions = methodOptions.setOptions(options);
        await I.focus(Selector(element, this.actualOptions).filterVisible());
    }

    async hoverAndClick(element: string, options?: { index?: number, timeout?: number, retries?: number, interval?: number }) {
        this.actualOptions = methodOptions.setOptions(options);
        // await this.shouldExist(element, this.actualOptions);
        // await this.shouldBeVisible(element, this.actualOptions);
        await I.waitForSelectActionabilityCheck(Selector(element).filterVisible(), [`attached`, 'stable'])
            .hover(Selector(element, this.actualOptions).filterVisible(), this.actualOptions)
            .click(Selector(element, this.actualOptions).filterVisible(), this.actualOptions);
    }

    async hoverAndClickByIndex(element: string, index: number, options?: { timeout?: number, retries?: number, interval?: number }) {
        this.actualOptions = methodOptions.setOptions(options);
        // await this.shouldExist(element, this.actualOptions);
        // await this.shouldBeVisible(element, this.actualOptions);
        await I.waitForSelectActionabilityCheck(Selector(element).filterVisible().nth(index), [`attached`, 'stable'])
            .hover(Selector(element, this.actualOptions).filterVisible().nth(index), this.actualOptions)
            .click(Selector(element, this.actualOptions).filterVisible().nth(index), this.actualOptions);
    }

    //keyboard actions
    async pressTab() {
        await I.pressTabKey();
    }

    //interaction
    async set(element: string, value: string | number, options?: { index?: number, timeout?: number, interval?: number, retries?: number }) {
        this.actualOptions = methodOptions.setOptions(options);
        if (value === undefined) {
            return;
        }
        // await this.shouldExist(element, this.actualOptions);
        value = value + "";
        await this.shouldBeVisible(element, this.actualOptions);
        await this.click(element, this.actualOptions);
        await I.fillField(Selector(element, this.actualOptions).filterVisible(), value);
    }

    async paste(element: string, value: string | number, options?: { index?: number, timeout?: number, interval?: number, retries?: number }) {
        this.actualOptions = methodOptions.setOptions(options);
        if (value === undefined) {
            return;
        }
        // await this.shouldExist(element, this.actualOptions);
        value = value + "";
        await this.shouldBeVisible(element, this.actualOptions);
        await this.focus(element, this.actualOptions);
        await I.fillField(Selector(element, this.actualOptions).filterVisible(), value, {paste: true});
    }

    async setByCharacter(element: string, value: string | number, options?: { index?: number, timeout?: number, interval?: number, retries?: number }) {
        this.actualOptions = methodOptions.setOptions(options);
        if (value === undefined) {
            return;
        }
        value = value + "";
        await this.shouldBeVisible(element, this.actualOptions);
        await this.click(element, this.actualOptions);
        //await I.fillField(Selector(element, this.actualOptions).filterVisible(), value);
        let i = value.length;
        while (i > 0) {
            await controlsCommonActions.appendValue(element, value.substring(value.length - i, value.length - (i - 1)), options);
            await I.wait(20);
            i = i - 1;
        }
    }

    async appendValue(element: string, value: string | number, options?: { index?: number, timeout?: number, interval?: number, retries?: number }) {
        this.actualOptions = methodOptions.setOptions(options);
        if (value === undefined) {
            return;
        }
        // await this.shouldExist(element, this.actualOptions);
        value = value + "";
        await this.shouldBeVisible(element, this.actualOptions);
        await this.click(element, this.actualOptions);
        await I.appendField(Selector(element, this.actualOptions).filterVisible(), value);
    }


//wait methods
    async waitUntilVisibility(element: string, options?: { timeout?: number, interval?: number, retries?: number }) {
        this.actualOptions = methodOptions.setOptions(options);
        await I.waitForSelectorToBeVisible(Selector(element, this.actualOptions));
    }

    async waitUntilElementExists(element: string, options?: { timeout?: number, interval?: number, retries?: number }) {
        this.actualOptions = methodOptions.setOptions(options);
        await I.waitForSelectorToExist(Selector(element, this.actualOptions),
        )
    }

    async waitUntilElementNotExist(element: string, options?: { timeout?: number, interval?: number, retries?: number }) {
        this.actualOptions = methodOptions.setOptions(options);
        await I.waitForSelectorToNotExist(Selector(element, this.actualOptions));
    }

    async waitUntilVisibilityByText(element: string, text: string, options?: { timeout?: number, interval?: number, retries?: number, isCaseSensitive?: boolean }) {
        this.actualOptions = methodOptions.setOptions(options);
        if (this.actualOptions.isCaseSensitive) {
            await I.waitForSelectorToBeVisible(Selector(element, this.actualOptions).withText(text));
        } else {
            await I.waitForSelectorToBeVisible(Selector(element, this.actualOptions).withText(text.toLowerCase()));
        }
    }

    async waitUntilVisibilityByAttribute(element: string, attributeName: string, attributeValue?: string, options?: { timeout?: number, interval?: number, retries?: number }) {
        this.actualOptions = methodOptions.setOptions(options);
        await I.waitForSelectorToBeVisible(Selector(element, this.actualOptions).withAttribute(attributeName, attributeValue));
    }

    async waitUntilVisibilityByIndex(element: string, index: number, options?: { timeout?: number, interval?: number, retries?: number }) {
        this.actualOptions = methodOptions.setOptions(options);
        await I.waitForSelectorToBeVisible(Selector(element, this.actualOptions).nth(index));
    }

    async waitUntilCollectionOfElementsSizeIsGreaterOrEqual(element: string, expectedSize: number, options?: { timeout?: number, assertionTimeout?: number, interval?: number, retries?: number }) {
        this.actualOptions = methodOptions.setOptions(options);
        await I.waitForCondition({
            condition: async () => {
                const actualSize = await Selector(element).count;
                return actualSize >= expectedSize;
            },
            timeout: this.actualOptions.assertionTimeout,
            interval: this.actualOptions.interval,
            retries: this.actualOptions.retries
        })
    }

    async waitUntilCollectionOfElementsSizeIsLessThan(element: string, expectedSize: number, options?: { timeout?: number, assertionTimeout?: number, interval?: number, retries?: number }) {
        this.actualOptions = methodOptions.setOptions(options);
        await I.waitForCondition({
            condition: async () => {
                const actualSize = await Selector(element).count;
                return actualSize < expectedSize;
            },
            timeout: this.actualOptions.assertionTimeout,
            interval: this.actualOptions.interval,
            retries: this.actualOptions.retries
        })
    }

    async waitUntilInvisibility(element: string, options?: { timeout?: number, interval?: number, retries?: number }) {
        this.actualOptions = methodOptions.setOptions(options);
        await I.waitForSelectorToBeInvisible(Selector(element, this.actualOptions));
    }

    async waitUntilInvisibilityByIndex(element: string, index: number, options?: { timeout?: number, interval?: number, retries?: number }) {
        this.actualOptions = methodOptions.setOptions(options);
        await I.waitForSelectorToBeInvisible(Selector(element, this.actualOptions).nth(index));
    }

    async waitForSelectActionabilityCheck(element: string, checks: ActionabilityCheckTypes[], isFilterByVisibility = true) {
        if (isFilterByVisibility == false) {
            await I.waitForSelectActionabilityCheck(Selector(element), checks);
        } else {
            await I.waitForSelectActionabilityCheck(Selector(element).filterVisible(), checks);
        }
    }

    //assertions
    async shouldExist(element: string, options?: { index?: number, timeout?: number, interval?: number, retries?: number }) {
        this.actualOptions = methodOptions.setOptions(options);
        await I.expectSelector(Selector(element, this.actualOptions).nth(this.actualOptions.index)).toExist();
    }

    async shouldNotExist(element: string, options?: { index?: number, timeout?: number, interval?: number, retries?: number }) {
        this.actualOptions = methodOptions.setOptions(options);
        await I.expectSelector(Selector(element, this.actualOptions).nth(this.actualOptions.index)).not.toExist();
    }

    async shouldBeVisible(element: string, options?: { index?: number, timeout?: number, assertionTimeout?: number, interval?: number, retries?: number }) {
        this.actualOptions = methodOptions.setOptions(options);
        await I.expect(Selector(element, this.actualOptions)
                .filterVisible().nth(this.actualOptions.index).visible,
            {
                timeout: this.actualOptions.assertionTimeout,
                interval: this.actualOptions.interval,
                retries: this.actualOptions.retries
            }).toBeOk();
    }

    async shouldBeVisibleByIndex(element: string, index: number, options?: {timeout?: number, assertionTimeout?: number, interval?: number, retries?: number }) {
        this.actualOptions = methodOptions.setOptions(options);
        await I.expect(Selector(element, this.actualOptions)
                .filterVisible().nth(index).visible,
            {
                timeout: this.actualOptions.assertionTimeout,
                interval: this.actualOptions.interval,
                retries: this.actualOptions.retries
            }).toBeOk();
    }


    async shouldNotBeVisible(element: string, options?: { index?: number, timeout?: number, assertionTimeout?: number, interval?: number, retries?: number, }) {
        this.actualOptions = methodOptions.setOptions(options);
        await I.expect(Selector(element, this.actualOptions)
            .nth(this.actualOptions.index).visible, {
            timeout: this.actualOptions.assertionTimeout,
            interval: this.actualOptions.interval,
            retries: this.actualOptions.retries
        })
            .not.toBeOk();
    }

    async shouldNotBeVisibleByIndex(element: string, index: number, options?: { timeout?: number, assertionTimeout?: number, interval?: number, retries?: number, }) {
        this.actualOptions = methodOptions.setOptions(options);
        await I.expect(Selector(element, this.actualOptions)
            .nth(index).visible, {
            timeout: this.actualOptions.assertionTimeout,
            interval: this.actualOptions.interval,
            retries: this.actualOptions.retries
        })
            .not.toBeOk();
    }

    async shouldHaveText(element: string, value: string, options?: { index?: number, timeout?: number, assertionTimeout?: number, interval?: number, retries?: number, isCaseSensitive?: boolean }) {
        this.actualOptions = methodOptions.setOptions(options);
        if (!this.actualOptions.isCaseSensitive) {
            await I.expect(async () => {
                return (await Selector(element, this.actualOptions).filterVisible()
                    .nth(this.actualOptions.index).innerText).toUpperCase();
            }, {
                timeout: this.actualOptions.assertionTimeout,
                interval: this.actualOptions.interval,
                retries: this.actualOptions.retries
            }).toContain(value.toUpperCase());
        } else {
            await I.expect(Selector(element, this.actualOptions)
                .filterVisible().nth(this.actualOptions.index).innerText, {
                timeout: this.actualOptions.assertionTimeout,
                interval: this.actualOptions.interval,
                retries: this.actualOptions.retries
            })
                .toContain(value);
        }
    }

    async shouldNotHaveText(element: string, value: string, options?: { index?: number, timeout?: number, assertionTimeout?: number, interval?: number, retries?: number, isCaseSensitive?: boolean }) {
        this.actualOptions = methodOptions.setOptions(options);
        if (!this.actualOptions.isCaseSensitive) {
            await I.expect(async () => {
                return (await Selector(element, this.actualOptions).filterVisible()
                    .nth(this.actualOptions.index).innerText).toUpperCase();
            }, {
                timeout: this.actualOptions.assertionTimeout,
                interval: this.actualOptions.interval,
                retries: this.actualOptions.retries
            }).not.toContain(value.toUpperCase());
        } else {
            await I.expect(Selector(element, this.actualOptions)
                .filterVisible().nth(this.actualOptions.index).innerText, {
                timeout: this.actualOptions.assertionTimeout,
                interval: this.actualOptions.interval,
                retries: this.actualOptions.retries
            })
                .not.toContain(value);
        }
    }

    async shouldHaveExactText(element: string, value: string, options?: { index?: number, timeout?: number, assertionTimeout?: number, interval?: number, retries?: number }) {
        this.actualOptions = methodOptions.setOptions(options);
        await I.expect(Selector(element, this.actualOptions)
            .filterVisible().nth(this.actualOptions.index).innerText, {
            timeout: this.actualOptions.assertionTimeout,
            interval: this.actualOptions.interval,
            retries: this.actualOptions.retries
        })
            .toEqual(value);
    }

    async shouldNotHaveExactText(element: string, value: string, options?: { index?: number, timeout?: number, assertionTimeout?: number, interval?: number, retries?: number }) {
        this.actualOptions = methodOptions.setOptions(options);
        await I.expect(Selector(element, this.actualOptions)
            .filterVisible().nth(this.actualOptions.index).innerText, {
            timeout: this.actualOptions.assertionTimeout,
            interval: this.actualOptions.interval,
            retries: this.actualOptions.retries
        })
            .not.toEqual(value);
    }

    async shouldHaveValue(element: string, value: string | number, options?: { index?: number, timeout?: number, assertionTimeout?: number, interval?: number, retries?: number, isCaseSensitive?: boolean }) {
        this.actualOptions = methodOptions.setOptions(options);
        value = value + "";
        await I.expect(Selector(element, this.actualOptions)
            .filterVisible().nth(this.actualOptions.index).value).not.toBeUndefined();
        if (!this.actualOptions.isCaseSensitive) {
            await I.expect(async () => {
                return (await Selector(element, this.actualOptions).filterVisible()
                    .nth(this.actualOptions.index).value).toUpperCase();
            }, {
                timeout: this.actualOptions.assertionTimeout,
                interval: this.actualOptions.interval,
                retries: this.actualOptions.retries
            }).toContain(value.toUpperCase());
        } else {
            await I.expect(Selector(element, this.actualOptions)
                .filterVisible().nth(this.actualOptions.index).value, {
                timeout: this.actualOptions.assertionTimeout,
                interval: this.actualOptions.interval,
                retries: this.actualOptions.retries
            })
                .toContain(value);
        }
    }

    async shouldNotHaveValue(element: string, value: string | number, options?: { index?: number, timeout?: number, assertionTimeout?: number, interval?: number, retries?: number, isCaseSensitive?: boolean }) {
        this.actualOptions = methodOptions.setOptions(options);
        value = value + "";
        await I.expect(Selector(element, this.actualOptions)
            .filterVisible().nth(this.actualOptions.index).value).not.toBeUndefined();
        if (!this.actualOptions.isCaseSensitive) {
            await I.expect(async () => {
                return (await Selector(element, this.actualOptions).filterVisible()
                    .nth(this.actualOptions.index).value).toUpperCase();
            }, {
                timeout: this.actualOptions.assertionTimeout,
                interval: this.actualOptions.interval,
                retries: this.actualOptions.retries
            }).not.toContain(value.toUpperCase());
        } else {
            await I.expect(Selector(element, this.actualOptions)
                .filterVisible().nth(this.actualOptions.index).value, {
                timeout: this.actualOptions.assertionTimeout,
                interval: this.actualOptions.interval,
                retries: this.actualOptions.retries
            })
                .not.toContain(value);
        }
    }

    async shouldBeEnabled(element: string, options?: { index?: number, timeout?: number, assertionTimeout?: number, interval?: number, retries?: number }) {
        this.actualOptions = methodOptions.setOptions(options);
        await I.expectSelector(Selector(element, this.actualOptions).filterVisible().nth(this.actualOptions.index), {
            timeout: this.actualOptions.assertionTimeout,
            interval: this.actualOptions.interval,
            retries: this.actualOptions.retries
        }).toBeEnabled();
    }

    async shouldBeDisabled(element: string, options?: { index?: number, timeout?: number, assertionTimeout?: number, interval?: number, retries?: number }) {
        this.actualOptions = methodOptions.setOptions(options);
        await I.expectSelector(Selector(element, this.actualOptions).filterVisible().nth(this.actualOptions.index), {
            timeout: this.actualOptions.assertionTimeout,
            interval: this.actualOptions.interval,
            retries: this.actualOptions.retries
        }).toBeDisabled();
    }

    async shouldNotBeBlank(element: string, options?: { index?: number, timeout?: number, assertionTimeout?: number, interval?: number, retries?: number }) {
        this.actualOptions = methodOptions.setOptions(options);
        await I.expect(Selector(element, this.actualOptions).filterVisible().nth(this.actualOptions.index).innerText, {
            timeout: this.actualOptions.assertionTimeout,
            interval: this.actualOptions.interval,
            retries: this.actualOptions.retries
        }).not.toEqual("");
    }

    async shouldNotBeBlankByIndex(element: string, index: number, options?: { timeout?: number, assertionTimeout?: number, interval?: number, retries?: number }) {
        this.actualOptions = methodOptions.setOptions(options);
        await I.expect(Selector(element, this.actualOptions).filterVisible().nth(index).innerText, {
            timeout: this.actualOptions.assertionTimeout,
            interval: this.actualOptions.interval,
            retries: this.actualOptions.retries
        }).not.toEqual("");
    }

    async isVisible(element: string, options?: { filterByVisibility?: boolean, index?: number, timeout?: number, interval?: number, retries?: number }) {
        this.actualOptions = methodOptions.setOptions(options);
        if (options?.filterByVisibility) {
            return await Selector(element, this.actualOptions).filterVisible().nth(this.actualOptions.index).visible;
        }
        return await Selector(element, this.actualOptions).nth(this.actualOptions.index).visible;
    }

    async isExists(element: string, options?: { index?: number, timeout?: number, interval?: number, retries?: number }) {
        this.actualOptions = methodOptions.setOptions(options);
        return await Selector(element, this.actualOptions).nth(this.actualOptions.index).exists;
    }

    async getValue(element: string) {
        await I.expect(Selector(element).filterVisible().value).not.toBeUndefined();
        this.value = await Selector(element).filterVisible().value;
        return this.value;
    }

    async getText(element: string) {
        this.text = await Selector(element).filterVisible().innerText;
        return this.text;
    }



    async shouldBeRequired(element: string, options?: { timeout?: number, assertionTimeout?: number, interval?: number, retries?: number }) {
        this.actualOptions = methodOptions.setOptions(options);
        await I.expect(Selector(element, this.actualOptions).filterVisible().getAttribute('validationtype'), {
            timeout: this.actualOptions.assertionTimeout,
            interval: this.actualOptions.interval,
            retries: this.actualOptions.retries
        }).toContain('required');
    }

    async shouldNotBeRequired(element: string, options?: { timeout?: number, assertionTimeout?: number, interval?: number, retries?: number }) {
        this.actualOptions = methodOptions.setOptions(options);
        await I.expect(Selector(element, this.actualOptions).filterVisible().getAttribute('validationtype'), {
            timeout: this.actualOptions.assertionTimeout,
            interval: this.actualOptions.interval,
            retries: this.actualOptions.retries
        }).not.toContain('required').or.toBeNull().or.toBeUndefined();
    }

    async shouldHaveValidationType(element: string, validationType: string, options?: { timeout?: number, assertionTimeout?: number, interval?: number, retries?: number }) {
        this.actualOptions = methodOptions.setOptions(options);
        await I.expect(Selector(element, this.actualOptions).filterVisible().getAttribute('validationtype'), {
            timeout: this.actualOptions.assertionTimeout,
            interval: this.actualOptions.interval,
            retries: this.actualOptions.retries
        }).toContain(validationType);
    }

    async shouldNotHaveValidationType(element: string, validationType: string, options?: { timeout?: number, assertionTimeout?: number, interval?: number, retries?: number }) {
        this.actualOptions = methodOptions.setOptions(options);
        await I.expect(Selector(element, this.actualOptions).filterVisible().getAttribute('validationtype'), {
            timeout: this.actualOptions.assertionTimeout,
            interval: this.actualOptions.interval,
            retries: this.actualOptions.retries
        }).toContain(validationType).or.toBeUndefined();
    }

    async setValueByJs(element: string, initialValue: string, formattedValue?: string) {
        await I.eval(({element, initialValue}) => {
            var inputField = document.evaluate(`${element}`, document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue;
            // @ts-ignore
            inputField.setAttribute('data-value', `${initialValue}`);
        }, {element: element, initialValue: initialValue});
        if (formattedValue) {
            await I.eval(({element, formattedValue}) => {
                var inputField = document.evaluate(`${element}`, document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue;
                // @ts-ignore
                inputField.value = formattedValue;

            }, {element: element, formattedValue: formattedValue});
        }
    }

}

export const controlsCommonActions = new ControlsCommonActions();

