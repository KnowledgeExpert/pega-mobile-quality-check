// Copyright 2020 Knowledge Expert SA
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.


import {controlsCommonActions} from '../controlsCommonActions';
import {radiobuttonCommon} from './radiobuttonCommon';
import {I, Selector} from 'test-maker';
import {methodOptions} from '../../../../helpers/options/methodOptions';
import {PegaErrorMessages} from '../pega-error-messages/pegaErrorMessages';

export class RadiobuttonByAttribute {

    private readonly attributeValue: string;
    public readonly container: string;
    private readonly attributeName: string;

    constructor(attributeName: string, attributeValue: string, container: string = '') {
        this.container = container;
        this.attributeName = attributeName;
        this.attributeValue = attributeValue;
    }

    public radioButtonGroupElement(): string {
        return `${this.container}//div[@data-ctl='RadioGroup'][@${this.attributeName}=\"${this.attributeValue}\"]`;
    }

    public radioButtonElements(): string {
        return `${this.container}//div[@data-ctl='RadioGroup'][@${this.attributeName}=\"${this.attributeValue}\"]//input[@type='radio']`;
    }

    public radioButtonElement(value: string): string {
        return `${this.container}//div[@data-ctl='RadioGroup'][@${this.attributeName}=\"${this.attributeValue}\"]//input[@type='radio' and @value='${value}']`;
    }

    public radioButtonLabelSelector(value: string) {
        return `${this.radioButtonElement(value)}/following-sibling::label`;
    }

    // public radioButtonElementToCheck(value: string): string {
    //     return `${this.container}//div[@data-ctl='RadioGroup'][@data-test-id='${this.testId}']//label[contains(@for, '${value}')]
    //     /parent::span[contains(@class, 'col')]/input[@type='radio']`;
    // }

    async waitUntilVisibility(value: string, options?: { timeout?: number, interval?: number, retries?: number }) {
        await controlsCommonActions.waitUntilVisibility(this.radioButtonElement(value), options);
    }

    async waitUntilElementExists(value: string, options?: { timeout?: number, interval?: number, retries?: number }) {
        await controlsCommonActions.waitUntilElementExists(this.radioButtonElement(value), options);
    }

    async waitUntilElementNotExist(value: string, options?: { timeout?: number, interval?: number, retries?: number }) {
        await controlsCommonActions.waitUntilElementNotExist(this.radioButtonElement(value), options);
    }

    async waitForSelectActionabilityCheck(value: string, checks, isFilterByVisibility = true) {
        await controlsCommonActions.waitForSelectActionabilityCheck(this.radioButtonElement(value), checks, isFilterByVisibility = true);
    }

    async shouldExist(value: string, options?: { index?: number, timeout?: number, assertionTimeout?: number, interval?: number, retries?: number }) {
        await controlsCommonActions.shouldExist(this.radioButtonElement(value), options);
    }

    async shouldNotExist(value: string, options?: { index?: number, timeout?: number, assertionTimeout?: number, interval?: number, retries?: number }) {
        await controlsCommonActions.shouldNotExist(this.radioButtonElement(value), options);
    }

    async waitUntilVisibilityByAttribute(value: string, attributeName: string, attributeValue?: string,
                                         options?: { timeout?: number, interval?: number, retries?: number }) {
        await controlsCommonActions.waitUntilVisibilityByAttribute(this.radioButtonElement(value), attributeName, attributeValue, options);
    }

    async waitUntilVisibilityByIndex(value: string, index: number, options?: { timeout?: number, interval?: number, retries?: number }) {
        await controlsCommonActions.waitUntilVisibilityByIndex(this.radioButtonElement(value), index, options);
    }

    async waitUntilCollectionOfElementsSizeIsGreaterOrEqual(value: string, expectedSize: number,
                                                            options?: { timeout?: number, interval?: number, retries?: number }) {
        await controlsCommonActions.waitUntilCollectionOfElementsSizeIsGreaterOrEqual(this.radioButtonElement(value), expectedSize, options);
    }

    async waitUntilCollectionOfElementsSizeIsLessThan(value: string, expectedSize: number,
                                                      options?: { timeout?: number, interval?: number, retries?: number }) {
        await controlsCommonActions.waitUntilCollectionOfElementsSizeIsLessThan(this.radioButtonElement(value), expectedSize, options);
    }

    async waitUntilInvisibility(value: string, options?: { timeout?: number, interval?: number, retries?: number }) {
        await controlsCommonActions.waitUntilInvisibility(this.radioButtonElement(value), options);
    }

    async waitUntilInvisibilityByIndex(value: string, index: number, options?: { timeout?: number, interval?: number, retries?: number }) {
        await controlsCommonActions.waitUntilInvisibilityByIndex(this.radioButtonElement(value), index, options);
    }

    async click(value: string, options?: { index?: number, timeout?: number, retries?: number, interval?: number }) {
        await controlsCommonActions.click(this.radioButtonLabelSelector(value), options);
    }

    async select(value: string, options?: { index?: number, timeout?: number, retries?: number, interval?: number }) {
        await controlsCommonActions.click(this.radioButtonLabelSelector(value), options);
    }

    async shouldBeVisible(value: string, options?: {index?: number,  timeout?: number, assertionTimeout?: number, interval?: number, retries?: number }) {
        await controlsCommonActions.shouldBeVisible(this.radioButtonLabelSelector(value), options);
    }

    async shouldNotBeVisible(value: string, options?: { index?: number, timeout?: number, assertionTimeout?: number, interval?: number, retries?: number }) {
        await controlsCommonActions.shouldNotBeVisible(this.radioButtonLabelSelector(value),options);
    }

    async shouldBeChecked(value: string, options?: { index?: number, timeout?: number, assertionTimeout?: number, interval?: number, retries?: number }) {
        await radiobuttonCommon.shouldBeChecked(this.radioButtonElement(value), options);
    }

    async shouldNotBeChecked(value: string, options?: { index?: number, timeout?: number, assertionTimeout?: number, interval?: number, retries?: number }) {
        await radiobuttonCommon.shouldNotBeChecked(this.radioButtonElement(value), options);
    }

    async shouldBeEnabled(value: string, options?: { index?: number, timeout?: number, assertionTimeout?: number, interval?: number, retries?: number }) {
        await controlsCommonActions.shouldBeEnabled(this.radioButtonElement(value), options);
    }

    async shouldBeDisabled(value: string, options?: { index?: number, timeout?: number, assertionTimeout?: number, interval?: number, retries?: number }) {
        await controlsCommonActions.shouldBeDisabled(this.radioButtonElement(value), options);
    }

    toString() {
        return `(Radio Button Group with '${this.attributeName}=${this.attributeValue}')`;
    }

    error() {
        return new PegaErrorMessages(this.radioButtonElements());
    }

    async isVisible(value: string, options?: { filterByVisibility?: boolean, index?: number, timeout?: number, assertionTimeout?: number, interval?: number, retries?: number }) {
        return await controlsCommonActions.isVisible(this.radioButtonElement(value), options);
    }

    async isExists(value: string, options?: { index?: number, timeout?: number, assertionTimeout?: number, interval?: number, retries?: number }) {
        return await controlsCommonActions.isExists(this.radioButtonElement(value), options);
    }
}
