// Copyright 2020 Knowledge Expert SA
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

import {I, Selector} from 'test-maker';
import {controlsCommonActions} from '../controlsCommonActions';
import {PegaErrorMessages} from '../pega-error-messages/pegaErrorMessages';


export class ButtonsActions {

    public readonly element : string;
    readonly index: number;

    constructor(element: string, index = 0) {
        this.element = element;
        this.index = index;
    }

    async shouldBeVisible(options?: {timeout?: number, assertionTimeout?: number, interval?: number, retries?: number }) {
        await controlsCommonActions.shouldBeVisibleByIndex(this.element, this.index, options);
    }

    async shouldNotBeVisible(options?: { timeout?: number, assertionTimeout?: number, interval?: number, retries?: number }) {
        await controlsCommonActions.shouldNotBeVisibleByIndex(this.element, this.index, options);
    }

    async click(options?: { timeout?: number, interval?: number, retries?: number }) {
        //await I.scrollToSelector(Selector(this.element).filterVisible(), 0, 0);
        await controlsCommonActions.hoverAndClickByIndex(this.element, this.index, options);
    }

    toString(): string {
        return `Button: ${this.element}`;
    }

    error() {
        return new PegaErrorMessages(this.element);
    }
}

