// Copyright 2020 Knowledge Expert SA
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

import {controlsCommonActions} from '../controlsCommonActions';
import {methodOptions} from '../../../../helpers/options/methodOptions';
import {I, logger, Selector} from 'test-maker';
import {PegaErrorMessages} from '../pega-error-messages/pegaErrorMessages';

export class AutocompletionCommon {

    public readonly element: string;

    constructor(element: string) {
        this.element = element;
    }

    private actualOptions;
    private elementToSelect: string;

    async waitUntilVisibility(options?: { timeout?: number, interval?: number, retries?: number }) {
        await controlsCommonActions.waitUntilVisibility(this.element, options);
    }

    async waitUntilVisibilityByText(text: string, options?: { timeout?: number, interval?: number, retries?: number }) {
        await controlsCommonActions.waitUntilVisibilityByText(this.element, text, options);
    }

    async waitUntilVisibilityByAttribute(attributeName: string, attributeValue?: string,
                                         options?: { timeout?: number, interval?: number, retries?: number }) {
        await controlsCommonActions.waitUntilVisibilityByAttribute(this.element, attributeName, attributeValue, options);
    }

    async waitUntilVisibilityByIndex(index: number, options?: { timeout?: number, interval?: number, retries?: number }) {
        await controlsCommonActions.waitUntilVisibilityByIndex(this.element, index, options);
    }

    async waitUntilCollectionOfElementsSizeIsGreaterOrEqual(expectedSize: number, options?: { timeout?: number, interval?: number, retries?: number }) {
        await controlsCommonActions.waitUntilCollectionOfElementsSizeIsGreaterOrEqual(this.element, expectedSize, options);
    }

    async waitUntilCollectionOfElementsSizeIsLessThan(expectedSize: number, options?: { timeout?: number, interval?: number, retries?: number }) {
        await controlsCommonActions.waitUntilCollectionOfElementsSizeIsLessThan(this.element, expectedSize, options);
    }

    async waitUntilInvisibility(options?: { timeout?: number, interval?: number, retries?: number }) {
        await controlsCommonActions.waitUntilInvisibility(this.element, options);
    }

    async waitUntilInvisibilityByIndex(index: number, options?: { timeout?: number, interval?: number, retries?: number }) {
        await controlsCommonActions.waitUntilInvisibilityByIndex(this.element, index, options);
    }

    async waitUntilElementExists(options?: { timeout?: number, interval?: number, retries?: number }) {
        await controlsCommonActions.waitUntilElementExists(this.element, options);
    }

    async waitUntilElementNotExist(options?: { timeout?: number, interval?: number, retries?: number }) {
        await controlsCommonActions.waitUntilElementNotExist(this.element, options);
    }

    async waitForSelectActionabilityCheck(checks, isFilterByVisibility = true) {
        await controlsCommonActions.waitForSelectActionabilityCheck(this.element, checks, isFilterByVisibility = true);
    }

    async shouldExist(options?: { timeout?: number, assertionTimeout?: number, interval?: number, retries?: number }) {
        await controlsCommonActions.shouldExist(this.element, options);
    }

    async shouldNotExist(options?: { timeout?: number, assertionTimeout?: number, interval?: number, retries?: number }) {
        await controlsCommonActions.shouldNotExist(this.element, options);
    }

    async click(options?: { timeout?: number, interval?: number, retries?: number }) {
        await controlsCommonActions.click(this.element, options);
    }

    async focus(options?: { timeout?: number, interval?: number, retries?: number }) {
        await controlsCommonActions.focus(this.element, options);
    }

    async pressTab() {
        await controlsCommonActions.pressTab();
    }

    async filterAndSelect(filter: string, text?: string, options?: { timeout?: number, interval?: number, retries?: number }) {
        this.actualOptions = methodOptions.setOptions(options);
        if (filter === undefined) {
            return;
        }
        if (!text) {
            text = filter;
        }
        const autocompletionItemByText = Selector(`.autocomplete-results .ac-item .match`,
            {timeout: this.actualOptions.timeout}).withExactText(`${text}`)
            .filterVisible();
        await I.fillField(this.element, filter)
            .wait(1000)
            .waitForSelectorToExist(autocompletionItemByText)
            .waitForSelectActionabilityCheck(autocompletionItemByText, ['attached'])
            .click(autocompletionItemByText);
    }


    async filter(filter: string | string[], options?: { index?: number, timeout?: number, interval?: number, retries?: number }) {
        if (filter === undefined || filter === null) {
            throw `Selected value must no be empty, but got ${filter}`;
        }
        await this.shouldExist(options);
        await this.click(options);
        let truncatedValue;
        typeof filter !== 'string' ? truncatedValue = filter[0] : truncatedValue = filter;
        if (truncatedValue.length >= 3) {
            truncatedValue = truncatedValue.substring(0, truncatedValue.length - 1);
        }
        await controlsCommonActions.set(this.element, truncatedValue, options);
    }

    async filterCharacterByCharacter(filter: string, intervalBetweenCharacters?: number, options?: { index?: number, timeout?: number, interval?: number, retries?: number }) {
        if (filter === undefined || filter === null) {
            throw `Selected value must no be empty, but got ${filter}`;
        }
        if (!intervalBetweenCharacters) {
            intervalBetweenCharacters = 1000;
        }
        await this.shouldExist(options);
        await this.click(options);
        await I.wait(500);
        let i = filter.length;
        while (i > 0) {
            await controlsCommonActions.appendValue(this.element, filter.substring(filter.length - i, filter.length - (i - 1)), options);
            await I.wait(intervalBetweenCharacters);
            i = i - 1;
        }
        await I.pressArrowDownKey();
    }

    async select(text: string, options?: { timeout?: number, interval?: number, retries?: number }) {
        this.actualOptions = methodOptions.setOptions(options);
        const autocompletionItemByText = Selector(`.autocomplete-results .ac-item .match`,
            {timeout: this.actualOptions.timeout}).withExactText(`${text}`)
            .filterVisible();
        await I.waitForSelectActionabilityCheck(autocompletionItemByText, ['attached'])
            .hover(autocompletionItemByText)
            .click(autocompletionItemByText);
    }

    async selectByIndex(index: number, options?: { timeout?: number, interval?: number, retries?: number }) {
        this.actualOptions = methodOptions.setOptions(options);
        await I.waitForSelectActionabilityCheck(Selector(`.autocomplete-results .ac-item .match`,
            this.actualOptions).nth(index), ['attached'])
            .click(Selector(`.autocomplete-results .ac-item .match`,
                this.actualOptions).nth(index));
    }

    // async selectResultFromExternalSource(plPropName: string, text: string, options?: { timeout?: number, interval?: number, retries?: number }) {
    //     this.actualOptions = methodOptions.setOptions(options);
    //     let elementSelector = `//table[contains (@pl_prop, "${plPropName}")]//tr[contains (@data-gargs, "${text}")]//td//span[contains(@class, "match-highlight")]`;
    //     await I.waitForSelectorToExist(elementSelector)
    //         .waitForSelectActionabilityCheck(Selector(elementSelector), ['attached'])
    //         .click(Selector(elementSelector, this.actualOptions));
    //     await this.shouldHaveValue(text);
    // }

    async getElementToSelect(plPropName: string, texts: string | string[]){
        let tableSelector: string = `//table[contains (@pl_prop, "${plPropName}")]`;
        let rowSelector: string = `//tr[@data-gargs]`;
        let collectionSelector = `${tableSelector}${rowSelector}`;
        let hasAllItems = true;
        let counter = 0;
        await I.waitForSelectorToExist(collectionSelector);
        await I.waitForSelectorToBeVisible(collectionSelector);
        let collectionCount = await Selector(collectionSelector).count;
        for (let j = 0; j < collectionCount; j++) {
            hasAllItems = true;
            let value = await Selector(collectionSelector).nth(j).getAttribute(`data-gargs`);
            //console.log(value);
            if (typeof texts === 'string') {
                if (value.indexOf(texts) === -1) {
                    hasAllItems = false;
                }
                if (hasAllItems) {
                    counter = j;
                    break;
                }
            } else {
                for (let i = 0; i < texts.length; i++) {
                    hasAllItems = true;
                    if (value.indexOf(texts[i]) === -1) {
                        hasAllItems = false;
                        break;
                    }
                }
                if (hasAllItems) {
                    counter = j;
                    break;
                }
            }
        }
        if (hasAllItems) {
            this.elementToSelect = `${tableSelector}${rowSelector}[${counter + 1}]//td//span[contains(@class, "match-highlight")]`;
        }
        if (!hasAllItems) {
            throw new Error(`There is no result for the given text ${texts}`);
        }
        return this.elementToSelect;
    }

    async selectResultFromExternalSource(plPropName: string, texts: string | string[], expectedValueAfterSelection?: string, options?: { timeout?: number, interval?: number, retries?: number }) {
        if (!texts) {
            throw Error(`Expecting at least 1 entry, but got ${texts}`);
        }
        if (!expectedValueAfterSelection) {
            typeof texts !== 'string' ? expectedValueAfterSelection = texts[0] : expectedValueAfterSelection = texts;
        }
        this.actualOptions = methodOptions.setOptions(options);
        let elementSelector: string = await this.getElementToSelect(plPropName, texts);

        await I.waitForSelectorToExist(elementSelector)
            .waitForSelectorToBeVisible(elementSelector)
            .hover(elementSelector)
            .click(Selector(elementSelector, this.actualOptions));
        await this.shouldHaveValue(expectedValueAfterSelection);
    }

    async selectResultFromExternalSourceByJsClick(plPropName: string, texts: string | string[], expectedValueAfterSelection?: string, options?: { timeout?: number, interval?: number, retries?: number }) {
        if (!texts) {
            throw Error(`Expecting at least 1 entry, but got ${texts}`);
        }
        if (!expectedValueAfterSelection) {
            // @ts-ignore
            typeof texts !== 'string' ? expectedValueAfterSelection = texts[0] : expectedValueAfterSelection = texts;
        }
        this.actualOptions = methodOptions.setOptions(options);
        let elementSelector: string = await this.getElementToSelect(plPropName, texts);
        await I.waitForSelectorToExist(elementSelector)
            .waitForSelectorToBeVisible(elementSelector);
        await I.eval(({item}) => {
            item.click();
        }, {item: Selector(`${elementSelector}`)});
        await this.shouldHaveValue(expectedValueAfterSelection);
    }

    async selectResultFromExternalSourceByJsClickWithRetries(plPropName: string, texts: string | string[], expectedValueAfterSelection?: string, options?: { timeout?: number, interval?: number, retries?: number }) {
        if (!texts) {
            throw Error(`Expecting at least 1 entry, but got ${texts}`);
        }
        if (!expectedValueAfterSelection) {
            typeof texts !== 'string' ? expectedValueAfterSelection = texts[0] : expectedValueAfterSelection = texts;
        }
        this.actualOptions = methodOptions.setOptions(options);
        let elementSelector: string = await this.getElementToSelect(plPropName, texts);
        await I.waitForCondition({
            condition: async () => {
                if (await Selector(elementSelector).exists && await Selector(elementSelector).visible) {
                    await I.eval(({item}) => {
                        item.click();
                    }, {item: Selector(`${elementSelector}`)});
                }
                return await Selector(this.element).value === expectedValueAfterSelection;
            },
            interval: this.actualOptions.interval,
            timeout: this.actualOptions.timeout,
            retryMessage: `Waiting for the autocomplete item to be selected`,
        });
    }

    async selectResultFromExternalSourceWithRetries(plPropName: string, texts: string | string[], expectedValueAfterSelection?: string, options?: { timeout?: number, interval?: number, retries?: number }) {
        if (!texts) {
            throw Error(`Expecting at least 1 entry, but got ${texts}`);
        }
        if (!expectedValueAfterSelection) {
            typeof texts !== 'string' ? expectedValueAfterSelection = texts[0] : expectedValueAfterSelection = texts;
        }
        this.actualOptions = methodOptions.setOptions(options);
        let elementSelector: string = await this.getElementToSelect(plPropName, texts);
        await I.waitForCondition({
            condition: async () => {
                if (await Selector(elementSelector).exists && await Selector(elementSelector).visible) {
                    await I.hover(elementSelector)
                        .click(elementSelector);
                }
                return await Selector(this.element).value === expectedValueAfterSelection;
            },
            interval: this.actualOptions.interval,
            timeout: this.actualOptions.timeout,
            retryMessage: `Waiting for the autocomplete item to be selected`,
        });
    }

    async filterAndSelectResultsFromExternalSource(plPropName: string, filterValue: string | string[], expectedValueAfterSelection?: string, options?: { timeout?: number, interval?: number, retries?: number }) {
        if (!expectedValueAfterSelection) {
            typeof filterValue !== 'string' ? expectedValueAfterSelection = filterValue[0] : expectedValueAfterSelection = filterValue;
        }
        this.actualOptions = methodOptions.setOptions(options);
        await this.filter(filterValue);
        await this.selectResultFromExternalSource(plPropName, filterValue, expectedValueAfterSelection, options);
    }

    async filterAndSelectResultsFromExternalSourceWithRetries(plPropName: string, filterValue: string | string[], expectedValueAfterSelection?: string, options?: { timeout?: number, interval?: number, retries?: number }) {
        if (!expectedValueAfterSelection) {
            typeof filterValue !== 'string' ? expectedValueAfterSelection = filterValue[0] : expectedValueAfterSelection = filterValue;
        }
        this.actualOptions = methodOptions.setOptions(options);
        await this.filter(filterValue);
        await this.selectResultFromExternalSourceWithRetries(plPropName, filterValue, expectedValueAfterSelection, options);
    }

    async filterAndSelectResultsFromExternalSourceByJsClick(plPropName: string, filterValue: string | string[], expectedValueAfterSelection?: string, options?: { timeout?: number, interval?: number, retries?: number }) {
        if (!expectedValueAfterSelection) {
            typeof filterValue !== 'string' ? expectedValueAfterSelection = filterValue[0] : expectedValueAfterSelection = filterValue;
        }
        this.actualOptions = methodOptions.setOptions(options);
        await this.filter(filterValue);
        await this.selectResultFromExternalSourceByJsClick(plPropName, filterValue, expectedValueAfterSelection, options);
    }

    async filterAndSelectResultsFromExternalSourceByJsClickWithRetries(plPropName: string, filterValue: string | string[], expectedValueAfterSelection?: string, options?: { timeout?: number, interval?: number, retries?: number }) {
        if (!expectedValueAfterSelection) {
            typeof filterValue !== 'string' ? expectedValueAfterSelection = filterValue[0] : expectedValueAfterSelection = filterValue;
        }
        this.actualOptions = methodOptions.setOptions(options);
        await this.filter(filterValue);
        await this.selectResultFromExternalSourceByJsClickWithRetries(plPropName, filterValue, expectedValueAfterSelection, options);
    }

    // async filterAndSelectResultsWithComponents(plPropName: string, filterValue: string, texts: string[], options?: { timeout?: number, interval?: number, retries?: number }) {
    //     this.actualOptions = methodOptions.setOptions(options);
    //     await this.filter(filterValue);
    //     await this.selectResultFromExternalSource(plPropName, texts, expectedValueAfterSelection, options);
    // }

    async assertSuggestedResultsFromExternalSourceAre(plPropName: string, texts: string[], options?: { timeout?: number, assertionTimeout?: number, interval?: number, retries?: number }) {
        this.actualOptions = methodOptions.setOptions(options);
        await this.openList();
        for (let i = 0; i < texts.length; i++) {
            await I.expect(Selector(`//table[contains (@pl_prop, "${plPropName}")]//tr[contains (@data-gargs, "${texts[i]}")]`,
                this.actualOptions).exists,
                {
                    timeout: this.actualOptions.assertionTimeout,
                    interval: this.actualOptions.interval,
                    retries: this.actualOptions.retries
                }).toBeOk();
        }
        await this.closeList();
    }

    async assertSuggestedResultsFromExternalSourceAreNotVisible(plPropName: string, texts: string[], options?: { timeout?: number, assertionTimeout?: number, interval?: number, retries?: number }) {
        this.actualOptions = methodOptions.setOptions(options);
        await this.openList();
        for (let i = 0; i < texts.length; i++) {
            await I.expect(Selector(`//table[contains (@pl_prop, "${plPropName}")]//tr[contains (@data-gargs, "${texts[i]}")]`,
                this.actualOptions)
                .exists, {
                timeout: this.actualOptions.assertionTimeout,
                interval: this.actualOptions.interval,
                retries: this.actualOptions.retries
            }).not.toBeOk();
        }
        await this.closeList();
    }

    async openList(options?: { timeout?: number, interval?: number, retries?: number }) {
        this.actualOptions = methodOptions.setOptions(options);
        await I.click(Selector(this.element, this.actualOptions)
            .filterVisible())
            .pressArrowDownKey();
    }

    async closeList(options?: { timeout?: number, interval?: number, retries?: number }) {
        this.actualOptions = methodOptions.setOptions(options);
        await I.click(Selector(this.element, this.actualOptions)
            .filterVisible());
    }

    async assertResultFromExternalSourceIsVisible(plPropName: string, text: string, options?: { timeout?: number, assertionTimeout?: number, interval?: number, retries?: number }) {
        this.actualOptions = methodOptions.setOptions(options);
        await I.expect(Selector(`//table[contains (@pl_prop, "${plPropName}")]//tr[contains (@data-gargs, "${text}")]`,
            this.actualOptions)
            .visible, {
            timeout: this.actualOptions.assertionTimeout,
            interval: this.actualOptions.interval,
            retries: this.actualOptions.retries
        }).toBeOk();
    }

    async assertResultFromExternalSourceIsNotVisible(plPropName: string, text: string, options?: { timeout?: number, assertionTimeout?: number, interval?: number, retries?: number }) {
        this.actualOptions = methodOptions.setOptions(options);
        await I.expect(Selector(`//table[contains (@pl_prop, "${plPropName}")]//tr[contains (@data-gargs, "${text}")]`,
            this.actualOptions)
            .visible, {
            timeout: this.actualOptions.assertionTimeout,
            interval: this.actualOptions.interval,
            retries: this.actualOptions.retries
        }).not.toBeOk();
    }

    async assertResultWithComponentsIsVisible(plPropName: string, texts: string[], options?: { timeout?: number, assertionTimeout?: number, interval?: number, retries?: number }) {
        this.actualOptions = methodOptions.setOptions(options);
        await I.expect(Selector(`//table[contains (@pl_prop, "${plPropName}")]//tr[contains (@data-gargs, "${texts.join('") and contains(@data-gargs, "',)}")]`,
            this.actualOptions)
            .visible, {
            timeout: this.actualOptions.assertionTimeout,
            interval: this.actualOptions.interval,
            retries: this.actualOptions.retries
        }).toBeOk();
    }

    async assertResultWithComponentsIsNotVisible(plPropName: string, texts: string[], options?: { timeout?: number, assertionTimeout?: number, interval?: number, retries?: number }) {
        this.actualOptions = methodOptions.setOptions(options);
        await I.expect(Selector(`//table[contains (@pl_prop, "${plPropName}")]//tr[contains (@data-gargs, "${texts.join('") and contains(@data-gargs, "',)}")]`,
            this.actualOptions)
            .visible, {
            timeout: this.actualOptions.assertionTimeout,
            interval: this.actualOptions.interval,
            retries: this.actualOptions.retries
        }).not.toBeOk();
    }

    async selectResultFromExternalSourceByIndex(plPropName: string, index: number, options?: { timeout?: number, interval?: number, retries?: number }) {
        this.actualOptions = methodOptions.setOptions(options);
        await I.waitForSelectActionabilityCheck(Selector(`//table[contains (@pl_prop, "${plPropName}")]//tr[@data-gargs]`).nth(index), ['attached'])
            .click(Selector(`//table[contains (@pl_prop, "${plPropName}")]//tr[@data-gargs][${index+1}]//td//span[contains(@class, "match-highlight")]`,
                this.actualOptions));
    }

    async shouldHaveSizeOfResultsFromExternalSource(plPropName: string, size: number, options?: { timeout?: number, assertionTimeout?: number, interval?: number, retries?: number }) {
        this.actualOptions = methodOptions.setOptions(options);
        let valuesList = `//table[contains (@pl_prop, "${plPropName}")]//tr[@data-gargs]/td[contains(@class, "autocomplete") and not(contains(@class, "hiddenCell"))]`
        if (await Selector(valuesList).visible) {
            await I.expect(Selector(valuesList,
                this.actualOptions).filterVisible().count, {
                timeout: this.actualOptions.assertionTimeout,
                interval: this.actualOptions.interval,
                retries: this.actualOptions.retries
            }).toEqual(size);
        }
       else {
           await logger.warn('The list or results is not visible');
           await I.expect(0).toEqual(size);
        }
    }

    async shouldBeVisible(options?: { index?: number, timeout?: number, assertionTimeout?: number, interval?: number, retries?: number }) {
        await controlsCommonActions.shouldBeVisible(this.element, options);
    }

    async shouldNotBeVisible(options?: { index?: number, timeout?: number, assertionTimeout?: number, interval?: number, retries?: number }) {
        await controlsCommonActions.shouldNotBeVisible(this.element, options);
    }

    async shouldHaveText(value: string, options?: { index?: number, timeout?: number, assertionTimeout?: number, interval?: number, retries?: number, isCaseSensitive?: boolean }) {
        await controlsCommonActions.shouldHaveText(this.element, value, options);
    }

    async shouldNotHaveText(value: string, options?: { index?: number, timeout?: number, assertionTimeout?: number, interval?: number, retries?: number, isCaseSensitive?: boolean }) {
        await controlsCommonActions.shouldNotHaveText(this.element, value, options);
    }

    async shouldHaveExactText(value: string, options?: { index?: number, timeout?: number, assertionTimeout?: number, interval?: number, retries?: number }) {
        await controlsCommonActions.shouldHaveExactText(this.element, value, options);
    }

    async shouldNotHaveExactText(value: string, options?: { index?: number, timeout?: number, assertionTimeout?: number, interval?: number, retries?: number }) {
        await controlsCommonActions.shouldNotHaveExactText(this.element, value, options);
    }

    async shouldHaveValue(value: string | number, options?: { index?: number, timeout?: number, assertionTimeout?: number, interval?: number, retries?: number, isCaseSensitive?: boolean }) {
        await controlsCommonActions.shouldHaveValue(this.element, value, options);
    }

    async shouldNotHaveValue(value: string | number, options?: { index?: number, timeout?: number, assertionTimeout?: number, interval?: number, retries?: number, isCaseSensitive?: boolean }) {
        await controlsCommonActions.shouldNotHaveValue(this.element, value, options);
    }

    async shouldHaveSizeOfResultsList(size: number, options?: { timeout?: number, assertionTimeout?: number, interval?: number, retries?: number }) {
        this.actualOptions = methodOptions.setOptions(options);
        await I.expect(Selector('.autocomplete-results li',
            this.actualOptions)
            .filterVisible().count, {
            timeout: this.actualOptions.assertionTimeout,
            interval: this.actualOptions.interval,
            retries: this.actualOptions.retries
        }).toEqual(size);
    }

    async shouldBeEnabled(options?: { index?: number, timeout?: number, assertionTimeout?: number, interval?: number, retries?: number }) {
        await controlsCommonActions.shouldBeEnabled(this.element, options);
    }

    async shouldBeDisabled(options?: { index?: number, timeout?: number, assertionTimeout?: number, interval?: number, retries?: number }) {
        await controlsCommonActions.shouldBeDisabled(this.element, options);
    }

    async shouldBeRequired(options?: { timeout?: number, assertionTimeout?: number, interval?: number, retries?: number }) {
        await controlsCommonActions.shouldBeRequired(this.element, options);
    }

    async shouldNotBeRequired(options?: { timeout?: number, assertionTimeout?: number, interval?: number, retries?: number }) {
        await controlsCommonActions.shouldNotBeRequired(this.element, options);
    }

    async shouldHaveValidationType(validationType: string, options?: { timeout?: number, assertionTimeout?: number, interval?: number, retries?: number }) {
        await controlsCommonActions.shouldHaveValidationType(this.element, validationType, options);
    }

    async shouldNotHaveValidationType(validationType: string, options?: { timeout?: number, assertionTimeout?: number, interval?: number, retries?: number }) {
        await controlsCommonActions.shouldNotHaveValidationType(this.element, validationType, options);
    }

    async getValue() {
        return await controlsCommonActions.getValue(this.element);
    }

    async getText() {
        return await controlsCommonActions.getText(this.element);
    }

    error() {
        return new PegaErrorMessages(this.element);
    }

    async isVisible(options?: { filterByVisibility?: boolean, index?: number, timeout?: number, assertionTimeout?: number, interval?: number, retries?: number }) {
        return await controlsCommonActions.isVisible(this.element, options);
    }

    async isExists(options?: { index?: number, timeout?: number, assertionTimeout?: number, interval?: number, retries?: number }) {
        return await controlsCommonActions.isExists(this.element, options);
    }

 }