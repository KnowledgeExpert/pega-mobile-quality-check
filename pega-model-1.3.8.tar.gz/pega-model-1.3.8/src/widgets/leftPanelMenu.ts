// Copyright 2020 Knowledge Expert SA
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

import {I, Selector} from 'test-maker';
import {methodOptions, Options} from '../../helpers/options/methodOptions';
import {pega} from '../pega';

export class LeftPanelMenu {

    private readonly NORMALIZE_SPACE_XPATH = "normalize-space(translate(string(.), '\t\n\r\u00a0', '    '))";

    private actualOptions;
    readonly searchFieldElement = 'i[data-test-id="2018081314444308025608"]';
    readonly plusIconElement = '[class="menu-item-icon-imageclass pi pi-plus"]';

    async expand(expectedMenuItem = "Create") {
        await pega.elementByCss(this.plusIconElement).hover();
        await I.waitForSelectorToExist(Selector(".menu-item-title-wrap").withText(expectedMenuItem));
    }

    async createNewCase(caseName: string, options?: { timeout: number, interval?: number, retries?: number }) {
        this.actualOptions = methodOptions.setOptions(options);
        await I.resizeWindow( 1500, 900);
        await I.waitForSelectorToExist(Selector(this.plusIconElement, this.actualOptions));
        await I.waitForSelectActionabilityCheck(Selector(this.plusIconElement), [`attached`, 'stable']);
        await I.click(Selector(this.plusIconElement, this.actualOptions))
            .click(Selector(`//*[@class="menu-item-title-wrap"]//span[text()="${caseName}"]`, this.actualOptions).filterVisible());
    }

    async selectItem(item: string, options?: { timeout: number, interval?: number, retries?: number }) {
        this.actualOptions = methodOptions.setOptions(options);
        await I.waitForSelectorToExist(Selector(this.plusIconElement, this.actualOptions));
        await I.waitForSelectActionabilityCheck(Selector(this.plusIconElement), [`attached`, 'stable']);
        await I.click(Selector(this.plusIconElement, this.actualOptions));
        await pega.menu().select(item);
    }

    async search(value: string, options?: { timeout: number, interval?: number, retries?: number }) {
        this.actualOptions = methodOptions.setOptions(options);
        await I.waitForSelectorToExist(Selector(this.searchFieldElement, this.actualOptions))
            .waitForSelectActionabilityCheck(Selector(this.searchFieldElement), [`attached`, 'stable'])
            .hover(Selector(this.searchFieldElement))
            .click(Selector(this.searchFieldElement))
            .fillField(this.searchFieldElement, value)
            .pressEnterKey();
    }
}
