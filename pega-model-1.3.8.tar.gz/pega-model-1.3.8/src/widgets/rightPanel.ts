// Copyright 2021 Knowledge Expert SA
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

import {I, Selector} from 'test-maker';
import {pega} from '../pega';

export class RightPanel {

    filesAndDocumentsCard = '//div[@data-test-id="201810250605180888507"]';
    fileLink = '//a[@data-test-id="201707140015270956e9d44b20-d360-4229-ad21-b96eeb9488e9857"]';
    followersCard = '//div[@data-test-id="201803300744210880502"]';
    stakeholdersCard = '//div[@data-test-id="201907260536110116488"]';
    tagsCard = '//div[@node_name="CaseTags"]';
    gearIcon = '//i[@class="pi pi-gear-solid"]';
    documentNameContainer = '//a[@data-test-id="201707140015270956e9d44b20-d360-4229-ad21-b96eeb9488e9857"]';
    followerNameContainer = '//a[@data-test-id="201710100436480270133"]';

    async selectContentType(value: string) {
        await I.click(`//h3[@class="layout-group-item-title" and text()="${value}"]`);
    }


    async expand() {
        await I.click(Selector(`//button[@data-test-id="20190121082016015244271"]`).filterVisible());
    }

    async collapse() {
        await I.click(Selector(`//button[@data-test-id="20190121082016015244271"]`).filterVisible());
    }

    async attachDocumentViaRichTextEditor(args: { documentName: string, text: string, availableTo?: string }) {
        await I.click(`${this.filesAndDocumentsCard}${this.gearIcon}`);
        await pega.textInput('2017112402204702187426').set(args.documentName);
        await pega.richTextEditor.set(args.text);
        if (args.availableTo) {
            await pega.radioButton('2018100802225805169264').select(args.availableTo)
        }
        await pega.buttonByDataTestId('201609131617210408158756').click();

    }

    async assertDocumentNameIsVisibleByIndex(documentName: string, index?: number) {
        let documentNameElement = `${this.filesAndDocumentsCard}${this.documentNameContainer}`;
        index ? await I.expectSelector(Selector(documentNameElement).nth(index)).toHaveInnerText(documentName)
            : await I.expectSelector(Selector(documentNameElement)).toHaveInnerText(documentName);
    }

    async attachDocumentAsLocalFile(args: { filePath: string, documentName: string, text?: string, availableTo?: string }) {
        await I.click(`${this.filesAndDocumentsCard}${this.gearIcon}`);
        await this.selectContentType('Local file');
        await I.setFilesToUpload('//div[@id="modalWrapper"]//input[@type="file"]', args.filePath);
        await pega.textInput('2017112402204702187426').set(args.documentName);
        if(args.text) {
            await pega.richTextEditor.set(args.text);
        }
        if (args.availableTo) {
            await pega.radioButton('2018100802225805169264').select(args.availableTo)
        }
        //await pega.buttonByDataTestId('201609131617210408158756').click();
    }

    async addUrl(args: {documentName: string, url: string, attachmentCategory?: string}) {
        await I.click(`${this.filesAndDocumentsCard}${this.gearIcon}`);
        await this.selectContentType('Url');
        await pega.textInput('2017091508022700351752').set(args.documentName);
        await pega.textInput('2017091508022700352218').set(args.documentName);
        if(args.attachmentCategory) {
            await pega.dropdownById('Category').select(args.attachmentCategory);
        }
        await pega.buttonByDataTestId('201609131617210408158756').click();
    }

    async addFollowers(value: string) {
        await I.click(`${this.followersCard}${this.gearIcon}`);
        await pega.multiselectById('83c9c0fc').selectOneValueFromList(value);
        await pega.buttonByDataTestId('20170926012248075624504').click();
        await pega.buttonByDataTestId('201910080634100105183889').click();
    }

    async assertFollowersListIncludes(...values: string[]) {
       let followerNameElement = Selector(`${this.followersCard}${this.followerNameContainer}`);
       for (let i=0; i<await followerNameElement.count; i++) {
           await I.expectSelector(followerNameElement).toHaveInnerText(values[i]);
       }
    }
}