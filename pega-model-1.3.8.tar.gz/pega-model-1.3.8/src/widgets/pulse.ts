// Copyright 2020 Knowledge Expert SA
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the L

import {I, Selector} from 'test-maker';
import {methodOptions, Options} from '../../helpers/options/methodOptions';
import {textAreaByAttribute} from './controls/textarea/textAreaByAttribute';
import {pega} from '../pega';

export class Pulse {

    private actualOptions;

    // async togglePulse(options?: { timeout: number, interval?: number, retries?: number }) {
    //     this.actualOptions = methodOptions.setOptions(options);
    //     await I.click(Selector('[data-test-id="201608300355460916284628"][title="Toggle pulse"]', this.actualOptions).filterVisible());
    // }
    //
    // async startConversation(options?: { timeout: number, interval?: number, retries?: number }) {
    //     this.actualOptions = methodOptions.setOptions(options);
    //     await I.click(Selector('#pyMessage', this.actualOptions));
    // }
    //

    async postTheMessage(value: string, options?: { timeout: number, interval?: number, retries?: number }) {
       await this.set(value, options);
       await this.clickPostButton();
    }

    async addAttachment(filePath: string) {
        await pega.textArea('2015070806333408619136').click();
        await I.setFilesToUpload('input[type="file"]', filePath);
    }

    async clickPostButton(options?: { timeout: number, interval?: number, retries?: number }) {
        this.actualOptions = methodOptions.setOptions(options);
        await pega.buttonByDataTestId('2015070902382006111577').click(this.actualOptions);
    }

    async set(value: string, options?: { timeout: number, interval?: number, retries?: number }) {
        this.actualOptions = methodOptions.setOptions(options);
        await pega.textArea('2015070806333408619136').click();
        await pega.textArea('2015070806333408619136').set(value, this.actualOptions);
    }

    async collapse(){
        await pega.textArea('2015070806333408619136').click();
        await I.click('button[data-test-id="2018011003123805519250"] i');
    }

    async shouldHaveMessageByIndex(text: string, index?: number, options?: { timeout: number, interval?: number, retries?: number }) {
        this.actualOptions = methodOptions.setOptions(options);
        let actualIndex: number;
        index? actualIndex = index :  actualIndex = 0;
        await I.expectSelector(Selector('//div[@data-test-id="201805161859330178213"]//p', this.actualOptions).nth(actualIndex)).toHaveInnerText(text);
    }

    async shouldHaveTruncatedDocumentNameByIndex(text: string, index?: number, options?: { timeout: number, interval?: number, retries?: number }) {
        this.actualOptions = methodOptions.setOptions(options);
        let actualIndex: number;
        index? actualIndex = index :  actualIndex = 0;
        await I.expectSelector(Selector('//div[@data-test-id="201803171705040043287"]//a', this.actualOptions).nth(actualIndex)).toHaveInnerText(`   ${text}   `);
    }

    async shouldHaveFullDocumentNameByIndex(text: string, index?: number, options?: { timeout: number, interval?: number, retries?: number }) {
        this.actualOptions = methodOptions.setOptions(options);
        let actualIndex: number;
        index? actualIndex = index :  actualIndex = 0;
        await I.expect(Selector('//div[@data-test-id="201803171705040043287"]//a', this.actualOptions).nth(actualIndex).getAttribute('title'))
            .toContain(text);
    }

    async comment(text: string, index?: number, options?: { timeout: number, interval?: number, retries?: number }) {
        this.actualOptions = methodOptions.setOptions(options);
        let actualIndex: number;
        index? actualIndex = index :  actualIndex = 0;
        await I.click(Selector('[data-test-id="2017100810231405039326"]').nth(actualIndex));
        await pega.textArea('20150717050721047637686').waitUntilVisibility();
        await pega.textArea('20150717050721047637686').click();
        await pega.textArea('20150717050721047637686').set(text);
        await pega.buttonByDataTestId('20170310074346004263527').click();
    }

    async commentAndUploadFile(args: {text?: string, index?: number, filePath: string}, options?: { timeout: number, interval?: number, retries?: number }) {
        this.actualOptions = methodOptions.setOptions(options);
        let actualIndex: number;
        args.index? actualIndex = args.index :  actualIndex = 0;
        await I.click(Selector('[data-test-id="2017100810231405039326"]').nth(actualIndex));
        if(args.text) {
            await pega.textArea('20150717050721047637686').waitUntilVisibility();
            await pega.textArea('20150717050721047637686').click();
            await pega.textArea('20150717050721047637686').set(args.text);
        }
        await I.setFilesToUpload('//div[@data-test-id="201712270846450265615"]//input[@type="file"]', args.filePath);
        await pega.buttonByDataTestId('20170310074346004263527').click();
    }

    async like(index?: number, options?: { timeout: number, interval?: number, retries?: number }) {
        this.actualOptions = methodOptions.setOptions(options);
        let actualIndex: number;
        index? actualIndex = index :  actualIndex = 0;
        await I.click(Selector('[data-test-id="20170519033013013528275"]').nth(actualIndex));
    }

    async open() {
        await pega.menu().select('Pulse');
    }
}
