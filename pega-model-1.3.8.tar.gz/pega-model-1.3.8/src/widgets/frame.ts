// Copyright 2020 Knowledge Expert SA
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

import {I, Selector} from 'test-maker';
import {methodOptions, Options} from '../../helpers/options/methodOptions';

export class Frame {

    readonly iframe: string = "//div[@style='display: block;']//iframe[contains(@id, 'PegaGadget')]";
    readonly workarea: string = "#workarea";
    private actualOptions;

    async switchToWorkAreaIframe(iframeTimeout=500, options?: { timeout: number, interval?: number, retries?: number }) {
        // console.log(await Selector(`//div[@style='display: block;']//iframe[contains(@id, 'PegaGadget')]`).getAttribute('id'));
            this.actualOptions = methodOptions.setOptions(options);

        // await I.wait(iframeTimeout)
            await I.switchToMainFrame()
            .waitForSelectorToExist(this.iframe)
            .switchToFrame(Selector(this.iframe, this.actualOptions));
    }

    async switchToTheWorkAreaIframeAndWaitForTheElement(waitForSelectorToBeVisibleSelector: string, iframeTimeout=10000) {
        await I.waitForCondition({
            condition: async () => {
                try {
                    await I.switchToMainFrame()
                        .waitForSelectorToExist(this.iframe)
                        // .waitForFrameToLoad(iframe) TODO figure out why waitForFrameToLoad is failing
                        .switchToFrame(this.iframe);
                    if (waitForSelectorToBeVisibleSelector !== undefined) {
                        await I.waitForSelectorToBeVisible(Selector(waitForSelectorToBeVisibleSelector, {timeout:  iframeTimeout }));
                    }
                    console.log(
                        `Selector '${waitForSelectorToBeVisibleSelector}' visible after switching to frame '${iframeTimeout}'`,
                    );
                    return true;
                } catch (error) {
                    // console.error(
                    //     `Selector '${waitForSelectorToBeVisibleSelector}' not visible after switching to frame '${this.iframe}'`,
                    // );
                    return false;
                }
            },
            timeout: 20000,
        });
    }

    async switchToFormFactoriFrame(options?: { timeout: number, interval?: number, retries?: number }) {
        this.actualOptions = methodOptions.setOptions(options);
        let iframe: string = '[id="FormFactoriFrame"]';
        await I.switchToMainFrame()
            .switchToFrame(Selector(iframe, this.actualOptions).filterVisible());
    }

    async switchToDefault() {
        await I.switchToMainFrame();
    }

    async ensureInWorkArea(timeoutForIframes = 4000, options?: { timeout: number, interval?: number, retries?: number }) {
        this.actualOptions = methodOptions.setOptions(options);
        // await I.wait(timeoutForIframes);
        await I.switchToMainFrame();
        // await I.wait(timeoutForIframes /4)
            await I.switchToFrame(Selector(this.iframe, this.actualOptions));
        try {
            await I.expect(Selector(this.workarea).visible, this.actualOptions).not.toBeOk();
        } catch (e) {
            await I.switchToMainFrame();
            //await I.wait(timeoutForIframes /4);
            await I.switchToFrame(Selector(this.iframe, this.actualOptions));
            console.log(e + " Second attempt to switch an iframe");
            await I.expect(Selector(this.workarea).visible, this.actualOptions).not.toBeOk();
        }
    }

    async waitToBeLoaded(options?: { timeout: number, interval?: number, retries?: number }) {
        this.actualOptions = methodOptions.setOptions(options);
        await I.waitForSelectorToExist(Selector(this.iframe, this.actualOptions));
    }
}