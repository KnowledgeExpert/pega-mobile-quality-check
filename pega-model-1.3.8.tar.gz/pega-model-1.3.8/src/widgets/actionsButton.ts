// Copyright 2019 Knowledge Expert SA
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.


import {Selector, I} from 'test-maker';
import {methodOptions} from '../../helpers/options/methodOptions';

export class ActionsMenu {

    public buttonSelector: string;

    constructor(buttonSelector: string) {
        this.buttonSelector = buttonSelector;
    }

    //private readonly button: string = '//button[contains(@title, "ctions")]';


    //private readonly buttonOnTheLastScreen: Selector = Selector('//button[contains(@data-test-id, "2014100911285001362285")]');

    private readonly menuItems: string = '//ul[contains(@id, "pyNavigation")]//span[@class="menu-item-title"]';

    private actualOptions;

    private async waitForActionsMenuButtonToBeVisible(options?: {
        timeout?: number;
        interval?: number;
        retries?: number;
    }) {
        await I.waitForSelectorToBeVisible(Selector(this.buttonSelector, options));
    }

    private async waitForActionsMenuButtonToBeEnabled() {
        await I.waitForSelectActionabilityCheck(Selector(this.buttonSelector), ["stable", "visible", "enabled"]);
    }

    async selectOption(menuItem: string, options?: { timeout?: number; interval?: number; retries?: number }) {
        this.actualOptions = methodOptions.setOptions(options);
        await this.open(this.actualOptions);
        await I.hover(Selector(this.menuItems, this.actualOptions).filterVisible().withExactText(menuItem)).click(
            Selector(this.menuItems, this.actualOptions).filterVisible().withExactText(menuItem));
    }

    //await I.waitForSelectorToBeInvisible(Selector(this.menuItems, options));

    async refresh(menuItem: string = `Refresh`, options?: { timeout?: number; interval?: number; retries?: number }) {
        await this.selectOption(menuItem, options);
    }

    async open(options?: { timeout?: number; interval?: number; retries?: number }) {
        this.actualOptions = methodOptions.setOptions(options);
        await this.waitForActionsMenuButtonToBeVisible(this.actualOptions);
        await I.waitForCondition({
            condition: async () => {
                await I.hover(Selector(this.buttonSelector, this.actualOptions)).click(Selector(this.buttonSelector, this.actualOptions));
                return await Selector(this.menuItems).visible;
            },
            interval: this.actualOptions.interval,
            timeout: this.actualOptions.timeout,
            retryMessage: `Waiting for the Actions menu to be opened`,
        });
    }


    async close(options?: { timeout?: number; interval?: number; retries?: number }) {
        this.actualOptions = methodOptions.setOptions(options);
        await this.waitForActionsMenuButtonToBeVisible(this.actualOptions);
        await I.pressKey('Escape');
        await I.waitForSelectorToBeInvisible(Selector(this.menuItems, this.actualOptions));
    }

    // async selectOptionOnTheLastScreen(menuItem: string) {
    //     await I.wait(4000)
    //         .click(this.buttonOnTheLastScreen)
    //         .wait(4000)
    //         .hover((this.menuItems).withExactText(menuItem))
    //         .click((this.menuItems).withExactText(menuItem));
    // }

    async assertMenuItemSize(size: number,
                             options?: { timeout?: number; assertionTimeout?: number; interval?: number; retries?: number }) {
        this.actualOptions = methodOptions.setOptions(options);
        await this.waitForActionsMenuButtonToBeVisible(options);
        await this.open(this.actualOptions);
        await I.expect(Selector(this.menuItems, this.actualOptions).count, {
            timeout: options.assertionTimeout,
            interval: options.interval,
            retries: options.retries,
        }).toBeSameAs(size);
    }


    async isMenuItemVisible(menuItem: string, options?: { timeout?: number; assertionTimeout?: number; interval?: number; retries?: number }): Promise<boolean> {
        this.actualOptions = methodOptions.setOptions(options);
        const buttonIsVisible = await Selector(this.buttonSelector, this.actualOptions).exists && await Selector(this.buttonSelector, this.actualOptions).visible;
        if (buttonIsVisible) {
            await this.open(options);
            const menuItemIsVisible = await Selector(this.menuItems, options).withExactText(menuItem).filterVisible()
                .visible;
            await this.close(this.actualOptions);
            return menuItemIsVisible;
        } else {
            return false;
        }
    }

    async assertMenuItemIsVisible(menuItem: string, options?: { timeout?: number; assertionTimeout?: number; interval?: number; retries?: number }) {
        this.actualOptions = methodOptions.setOptions(options);
        await I.waitForSelectorToBeVisible(this.buttonSelector);
        await this.open(options);
        await I.expect(Selector(this.menuItems, this.actualOptions).withExactText(menuItem).filterVisible().visible).toBeTrue();
        await this.close(this.actualOptions);
    }

    async assertMenuItemIsNotVisible(menuItem: string, options?: { timeout?: number; assertionTimeout?: number; interval?: number; retries?: number }) {
        this.actualOptions = methodOptions.setOptions(options);
        await I.waitForSelectorToBeVisible(this.buttonSelector);
        await this.open(options);
        await I.expect(Selector(this.menuItems, this.actualOptions).filterVisible().withExactText(menuItem).visible, {
            timeout: this.actualOptions.assertionTimeout,
            interval: this.actualOptions.interval,
            retries: this.actualOptions.retries,
        }).not.toBeOk();
        await this.close(this.actualOptions);
    }

    async assertMenuItemDoesNotExist(menuItem: string, options?: { timeout?: number; assertionTimeout?: number; interval?: number; retries?: number }) {
        this.actualOptions = methodOptions.setOptions(options);
        await I.waitForSelectorToBeVisible(this.buttonSelector);
        await this.open(options);
        await I.expect(Selector(this.menuItems, this.actualOptions).filterVisible().withExactText(menuItem).exists, {
            timeout: this.actualOptions.assertionTimeout,
            interval: this.actualOptions.interval,
            retries: this.actualOptions.retries,
        }).not.toBeTrue();
        await this.close(this.actualOptions);
    }
}