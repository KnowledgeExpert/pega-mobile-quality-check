import {ActionsMenu} from './widgets/actionsButton';
import {Alerts} from './widgets/alerts';
import {AssignmentTitle} from './widgets/assignmentTitle';
import {Frame} from './widgets/frame';
import {Button} from './widgets/controls/buttons/button';
import {FormButtons} from './widgets/controls/buttons/formButtons';
import {CheckBox} from './widgets/controls/checkbox';
import {MultiSelect} from './widgets/controls/multiSelect';
import {ReadonlyTextInput} from './widgets/controls/readonlyTextInput';
import {Table} from './widgets/controls/table/table';
import {I, Selector, TestRunInfo} from 'test-maker';
import {Case} from './widgets/case';
import {Menu} from './widgets/menu';
import {ProgressBar} from './widgets/progressBar';
import {CaseWorkerMenu} from './widgets/caseWorkerMenu';
import {EmailAttachment} from './widgets/emailAttachment';
import {LeftPanelMenu} from './widgets/leftPanelMenu';
import {LoginForm} from './widgets/loginForm';
import {Pulse} from './widgets/pulse';
import {StepRouting} from './widgets/stepRouting';
import {TopPanel} from './widgets/topPanel';
import {Status} from './widgets/status';
import {CustomControlByAttributes} from './widgets/controls/customControl/customControlByAttribute';
import {CustomControlByXPath} from './widgets/controls/customControl/CustomConrolByXPath';
import {CustomControlByCss} from './widgets/controls/customControl/CustomControlByCss';
import {defaultOptions} from '../helpers/options/defaultOptions';
import {ImageElement} from './widgets/controls/image';
import {Logo} from './widgets/controls/logo';
import {AutocompletionByAttribute} from './widgets/controls/autocompletionField/autocompletionByAttribute';
import {AutocompletionByLabel} from './widgets/controls/autocompletionField/autocompletionByLabel';
import {AutocompletionByXPath} from './widgets/controls/autocompletionField/autocompletionByXPath';
import {AutocompletionByCss} from './widgets/controls/autocompletionField/autocompletionByCss';
import {TextInputByAttribute} from './widgets/controls/textInput/textInputByAttribute';
import {TextInputByLabel} from './widgets/controls/textInput/textInputByLabel';
import {TextInputByXPath} from './widgets/controls/textInput/textInputByXPath';
import {TextInputByCss} from './widgets/controls/textInput/textInputByCss';
import {DatePickerByXPath} from './widgets/controls/datePicker/datePickerByXPath';
import {DatePickerByAttribute} from './widgets/controls/datePicker/datePickerByAttribute';
import {DatePickerByCss} from './widgets/controls/datePicker/datePickerByCss';
import {DatePickerByLabel} from './widgets/controls/datePicker/datePickerByLabel';
import {DropdownByAttribute} from './widgets/controls/dropdown/dropdownByAttribute';
import {DropdownByCss} from './widgets/controls/dropdown/dropdownByCss';
import {DropdownByLabel} from './widgets/controls/dropdown/dropdownByLabel';
import {DropdownByXPath} from './widgets/controls/dropdown/dropdownByXPath';
import {TextAreaByAttribute} from './widgets/controls/textarea/textAreaByAttribute';
import {TextAreaByCss} from './widgets/controls/textarea/textAreaByCss';
import {TextAreaByLabel} from './widgets/controls/textarea/textAreaByLabel';
import {TextAreaByXPath} from './widgets/controls/textarea/textAreaByXPath';
import {Label} from './widgets/controls/label';
import {RichTextEditor} from './widgets/controls/richTextEditor';
import {RadiobuttonById} from './widgets/controls/radiobuttons/radiobuttonById';
import {RadiobuttonByAttribute} from './widgets/controls/radiobuttons/radiobuttonByAttribute';
import {ToDoList} from './widgets/toDoList';
import {RightPanel} from './widgets/rightPanel';
import {DateRange} from './widgets/controls/dateRange';
import {AnyPicker} from './widgets/controls/anyPicker';


export class Pega {

    async visit(url: string, runInfo?: TestRunInfo) {
        await I.goto(url);
        if (runInfo) {
            defaultOptions.setSelector(runInfo?.configuration?.runner?.timeout?.selector);
            defaultOptions.setAssertion(runInfo?.configuration?.runner?.timeout?.assertion);

            defaultOptions.getSelector();
            defaultOptions.getAssertion();
        } else {
            defaultOptions.setSelector(11111);
            defaultOptions.setAssertion(15555);

            defaultOptions.getSelector();
            defaultOptions.getAssertion();
        }
    }

    async switchToPegaExpress(): Promise<void> {
        await I.click('[data-test-id="switch-to-in-app-editing"]')
            .wait(2000);
    }

    async logoff(text: string = 'Log off', selector: string = `[data-test-id="px-opr-image-ctrl"]`) {
        await I.switchToMainFrame()
            .waitForSelectActionabilityCheck(selector, [`attached`, 'stable', 'visible'])
            .hover(selector)
            .click(selector)
            .waitForSelectorToBeVisible(Selector('.menu-item-title').withExactText(text))
            .click(Selector('.menu-item-title').withExactText(text));
    }

    async moveFocusOutside() {
        await I.click(`body`)
            .wait(2000);
    }


    readonly alert = new Alerts();
    readonly assignmentTitle = new AssignmentTitle();
    readonly case = new Case();
    readonly caseWorkerMenu = new CaseWorkerMenu();
    readonly emailAttachment = new EmailAttachment();
    readonly frame = new Frame();
    readonly leftPanelMenu = new LeftPanelMenu();
    readonly loginForm = new LoginForm();
    readonly progressBar = new ProgressBar();
    readonly pulse = new Pulse();
    readonly stepRouting = new StepRouting();
    readonly topPanel = new TopPanel();
    readonly status = new Status();
    readonly richTextEditor = new RichTextEditor();
    readonly rightPanel = new RightPanel();

    menu() {
        return new Menu();
    }

    actionsMenu = new ActionsMenu('//button[contains(@title, "ctions")]'); //the typo made on purpose
    // because title might be 'Actions' or 'Other Actions'

    actionsMenuBySelector(selector: string) {
        return new ActionsMenu(selector);
    }

    anypickerByDataTestId(dataTestId: string, container?: string) {
        return new AnyPicker(`data-test-id`, dataTestId, container)
    }

    anypickerById(id: string, container?: string) {
        return new AnyPicker(`id`, id, container)
    }

    autocompletionFieldBy(attributeName: string, attributeValue: string, container?: string) {
        return new AutocompletionByAttribute(attributeName, attributeValue, container)
    };

    autocompletionFieldById(id: string, container?: string) {
        return new AutocompletionByAttribute('id', id, container)
    };

    autocompletionField(dataTestId: string, container?: string) {
        return new AutocompletionByAttribute('data-test-id', dataTestId, container)
    };

    autocompletionFieldByDataTestId(dataTestId: string, container?: string) {
        return new AutocompletionByAttribute('data-test-id', dataTestId, container)
    };

    autocompletionFieldByLabel(label: string) {
        return new AutocompletionByLabel(label)
    };

    autocompletionFieldByXPath(xpath: string, container?: string) {
        return new AutocompletionByXPath(xpath, container)
    };

    autocompletionFieldByCss(css: string) {
        return new AutocompletionByCss(css)
    };

    buttonBy(attributeName: string, attributeValue: string, container?: string) {
        return new Button(attributeName, attributeValue, container)
    };

    buttonById(id: string, container?: string) {
        return new Button('id', id, container)
    };

    buttonByDataTestId(dataTestId: string, container?: string) {
        return new Button('data-test-id', dataTestId, container)
    };

    buttonByTitle(title: string, container?: string) {
        return new Button('title', title, container)
    };

    readonly button = new FormButtons();

    checkboxBy(attributeName: string, attributeValue: string, container?: string) {
        return new CheckBox(attributeName, attributeValue, container)
    };

    checkboxById(id: string, container?: string) {
        return new CheckBox('id', id, container)
    };

    checkboxByDataTestId(dataTestId: string, container?: string) {
        return new CheckBox('data-test-id', dataTestId, container)
    };

    checkbox(dataTestIs: string, container?: string) {
        return new CheckBox('data-test-id', dataTestIs, container)
    };

    datePickerBy(attributeName: string, attributeValue: string, container?: string) {
        return new DatePickerByAttribute(attributeName, attributeValue, container)
    };

    datePickerById(id: string, container?: string) {
        return new DatePickerByAttribute('id', id, container)
    };

    datePickerByDataTestId(dataTestId: string, container?: string) {
        return new DatePickerByAttribute('data-test-id', dataTestId, container)
    };

    datePicker(dataTestId: string, container?: string) {
        return new DatePickerByAttribute('data-test-id', dataTestId, container)
    };

    datePickerByXpath(xpath: string, container?: string) {
        return new DatePickerByXPath(xpath, container)
    };

    datePickerByCss(css: string) {
        return new DatePickerByCss(css)
    };

    datePickerByLabel(label: string, container?: string) {
        return new DatePickerByLabel(label, container)
    };

    dateRangeByDataTestId(dataTestId: string) {
        return new DateRange(dataTestId);
    }

    dropdownBy(attributeName: string, attributeValue: string, container?: string) {
        return new DropdownByAttribute(attributeName, attributeValue, container)
    };

    dropdownById(id: string, container?: string) {
        return new DropdownByAttribute('id', id, container)
    };

    dropdownByDataTestId(dataTestId: string, container?: string) {
        return new DropdownByAttribute('data-test-id', dataTestId, container)
    };

    dropdown(dataTestId: string, container?: string) {
        return new DropdownByAttribute('data-test-id', dataTestId, container)
    };

    dropdownByCss(css: string) {
        return new DropdownByCss(css)
    };

    dropdownByLabel(label: string, container?: string) {
        return new DropdownByLabel(label, container)
    };

    dropdownByXPath(xpath: string, container?: string) {
        return new DropdownByXPath(xpath, container)
    };

    elementByAttributes(args: { attributeName: string, attributeValue: string, elementType?: string, container?: string }) {
        return new CustomControlByAttributes({
            attributeName: args.attributeName,
            attributeValue: args.attributeValue,
            elementType: args.elementType,
            container: args.container
        })
    };

    elementById(args: {id: string, elementType?: string, container?: string }) {
        return new CustomControlByAttributes({
            attributeName: 'id',
            attributeValue: args.id,
            elementType: args.elementType,
            container: args.container
        })
    };

    elementByDataTestId(args: { dataTestId: string, elementType?: string, container?: string }) {
        return new CustomControlByAttributes({
            attributeName: 'data-test-id',
            attributeValue: args.dataTestId,
            elementType: args.elementType,
            container: args.container
        })
    };

    element(args: { dataTestId: string, elementType?: string, container?: string }) {
        return new CustomControlByAttributes({
            attributeName: 'data-test-id',
            attributeValue: args.dataTestId,
            elementType: args.elementType,
            container: args.container
        })
    };

    elementByXpath(xpath: string, container?: string) {
        return new CustomControlByXPath(xpath, container)
    };

    elementByCss(css: string) {
        return new CustomControlByCss(css)
    };

    image(dataTestId: string, container?: string) {
        return new ImageElement(`data-test-id`, dataTestId, container)
    };

    imageByTestId(dataTestId: string, container?: string) {
        return new ImageElement(`data-test-id`, dataTestId, container)
    };

    imageById(id: string, container?: string) {
        return new ImageElement(`id`, id, container)
    };

    imageBy(attributeName: string, attributeValue: string, container?: string) {
        return new ImageElement(attributeName, attributeValue, container)
    };

    imageBySource(src: string, container?: string) {
        return new ImageElement(`src`, src, container)
    };

    label(dataTestId: string, container?: string) {
        return new Label('data-test-id', dataTestId, container)
    };

    labelByTestId(dataTestId: string, container?: string) {
        return new Label('data-test-id', dataTestId, container)
    };

    labelByAttribute(attributeName: string, attributeValue: string, container?: string) {
        return new Label(attributeName, attributeValue, container)
    };

    logo() {
        return new Logo()
    };

    logoBy(attributeName: string, attributeValue: string) {
        return new Logo(attributeName, attributeValue)
    };

    multiselectBy(attributeName: string, attributeValue: string, args?) {
        return new MultiSelect(attributeName, attributeValue, args)
    };

    multiselectById(id: string, args?) {
        return new MultiSelect('id', id, args)
    };

    multiselectByIdDataTestId(dataTestId: string, args?) {
        return new MultiSelect('data-test-id', dataTestId, args)
    };

    multiselect(dataTestId: string, args?) {
        return new MultiSelect('data-test-id', dataTestId, args)
    };

    radioButtonByPartialId(partialId: string, container?: string) { //alias to radioButtonGroupByPartialId
        return new RadiobuttonById(partialId, container);
    };

    radioButtonGroupByPartialId(partialId: string, container?: string) { //alias to radioButtonByPartialId
        return new RadiobuttonById(partialId, container);
    };

    radioButtonByAriaLabel(ariaLabel: string, container?: string) { //alias to radioButtonGroupByAriaLabel
        return new RadiobuttonByAttribute('aria-label', ariaLabel, container);
    };

    radioButtonGroupByAriaLabel(ariaLabel: string, container?: string) { //alias to radioButtonByAriaLabel
        return new RadiobuttonByAttribute('aria-label', ariaLabel, container);
    };

    radioButtonByDataTestId(dataTestId: string, container?: string) { //alias to radioButtonGroupByDataTestId
        return new RadiobuttonByAttribute('data-test-id', dataTestId, container);
    };

    radioButtonGroupByDataTestId(dataTestId: string, container?: string) { //alias to radioButtonByDataTestId
        return new RadiobuttonByAttribute('data-test-id', dataTestId, container);
    };

    radioButton(dataTestId: string, container?: string) { //alias to radioButtonGroup
        return new RadiobuttonByAttribute('data-test-id', dataTestId, container);
    };

    radioButtonGroup(dataTestId: string, container?: string) { //alias to radioButton
        return new RadiobuttonByAttribute('data-test-id', dataTestId, container);
    };

    readonlyTextInputBy(attributeName: string, attributeValue: string, container?: string) {
        return new ReadonlyTextInput(attributeName, attributeValue, container)
    };

    readonlyTextInputById(id: string, container?: string) {
        return new ReadonlyTextInput('id', id, container)
    };

    readonlyTextInputByDataTestId(dataTestId: string, container?: string) {
        return new ReadonlyTextInput('data-test-id', dataTestId, container)
    };

    readonlyTextInput(dataTestId: string, container?: string) {
        return new ReadonlyTextInput('data-test-id', dataTestId, container)
    };

    tableByTestId(dataTestId: string, elementType: string="div", container?: string) {
        return new Table('data-test-id', dataTestId, elementType, container);
    };

    table(dataTestId: string, elementType: string="div", container?: string) {
        return new Table('data-test-id', dataTestId, elementType, container);
    };

    tableByTitle(plProp: string, elementType: string="table", container?: string) {
        return new Table('pl_prop', plProp, elementType, container);
    };

    tableBy(by: string, value: string, elementType: string, container?: string) {
        return new Table(by, value, elementType, container);
    };

    textAreaBy(attributeName: string, attributeValue: string, container?: string) {
        return new TextAreaByAttribute(attributeName, attributeValue, container)
    };

    textAreaById(id: string, container?: string) {
        return new TextAreaByAttribute('id', id, container)
    };

    textAreaByIdDataTestId(dataTestId: string, container?: string) { //toDo to be deleted because of typo
        return new TextAreaByAttribute('data-test-id', dataTestId, container)
    };

    textAreaByDataTestId(dataTestId: string, container?: string) {
        return new TextAreaByAttribute('data-test-id', dataTestId, container)
    };

    textArea(dataTestId: string, container?: string) {
        return new TextAreaByAttribute('data-test-id', dataTestId, container)
    };

    textAreaByCss(css: string) {
        return new TextAreaByCss(css)
    };

    textAreaByLabel(label: string, container?: string) {
        return new TextAreaByLabel(label, container)
    };

    textAreaByXpath(xpath: string, container?: string) {
        return new TextAreaByXPath(xpath, container)
    };

    textInputBy(attributeName: string, attributeValue: string, container?: string) {
        return new TextInputByAttribute(attributeName, attributeValue, container)
    };

    textInputById(id: string, container?: string) {
        return new TextInputByAttribute('id', id, container)
    };

    textInputByDataTestId(dataTestId: string, container?: string) {
        return new TextInputByAttribute('data-test-id', dataTestId, container)
    };

    textInput(dataTestId: string, container?: string) {
        return new TextInputByAttribute('data-test-id', dataTestId, container)
    };

    textInputByLabel(label: string, container?: string) {
        return new TextInputByLabel(label, container)
    };

    textInputByXPath(xpath: string, container?: string) {
        return new TextInputByXPath(xpath, container)
    };

    textInputByXpath(xpath: string, container?: string) {
        return new TextInputByXPath(xpath, container)
    };

    textInputByCss(css: string) {
        return new TextInputByCss(css)
    };

    toDoList(args?: {taskName?: string, caseName?: string, operatorName?: string}) {
        return new ToDoList(args);
    }


}

export const pega = new Pega();



