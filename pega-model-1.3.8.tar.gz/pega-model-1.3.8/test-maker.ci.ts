import {Configuration, reporters, mergeAndConcat} from "test-maker";
import {common, operatorsManager} from './test-maker.common';

const ci =  {
    //source: [`./src/specs/hooks-spec.ts`],
    extra: {
        env: {
            name: 'dev',
        },
        operatorsManager,
    },
    runner: {
        headless: true,
        parallel: 1
    },
    hooks: {
        beforeEachFeature: async (I, runInfo) => {
        },
        beforeEachScenario: async (I, runInfo) => {
            const name = runInfo.configuration.extra.env.name;
            console.log('Current environment=' + name);
            console.log('beforeEachScenario');
        }
    }

} as Configuration;

export default mergeAndConcat(common, ci);