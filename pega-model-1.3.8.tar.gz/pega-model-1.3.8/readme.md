# Test Maker PEGA Model
A utility belt library to work with PEGA and test-machine. 

## Localizer
The localizer allows to "translate" strings depending on the locale. Firstly you should init map using the method `Localizer.initData(data: any, locale = "en")`

Config:
```
data: any               // pass here js object which contains lang as keys, and object with phrases as value
locale: string          // which locale you want convert phrases to (default "en")
```

Examples:

* init data using js object:
  ```
  const map = {
      "fr": {
          "Hello": "Salut"
      }
  };
  Localizer.initData(map, "fr");

  l("Hello") // "Salut"
  ```

* init data using JSON:

  `file.json`
  ```
  {
    "fr": {
        "Hello": "Salut"
    }
  }
  ```

  ```
  const map = require("./path/to/file.json")
  Localizer.initData(map, "fr");

  l("Hello") // "Salut"
  ```
