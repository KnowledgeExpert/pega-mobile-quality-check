// Copyright 2020 Knowledge Expert SA
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.


import {defaultOptions} from './defaultOptions';

export class Options {

    setOptions(options?: {
        timeout?: number,
        interval?: number,
        retries?: number,
        assertionTimeout?: number,
        index?: number,
        isCaseSensitive?: boolean,
    }) {
        let actualOptions = {
            timeout: defaultOptions.getSelector(),
            interval: 50,
            retries: Math.trunc(defaultOptions.getSelector() / 50),
            assertionTimeout: defaultOptions.getAssertion(),
            index: 0,
            isCaseSensitive: true,
        }
        if (options?.timeout) {
            actualOptions.timeout = options.timeout;
        }
        if (options?.interval) {
            actualOptions.interval = options.interval;
        }
        if (options?.retries) {
            actualOptions.retries = options.retries;
        }
        if (options?.assertionTimeout) {
            actualOptions.assertionTimeout = options.assertionTimeout;
        }
        if (options?.index) {
            actualOptions.index = options.index;
        }
        if (options?.isCaseSensitive == false) {
            actualOptions.isCaseSensitive = false;
        }
        return actualOptions;
    }

    setOptionsAndIndex(index: number, options?: { timeout?: number, interval?: number, retries?: number, assertionTimeout?: number }) {
        let actualOptions = {
            index: index,
            timeout: defaultOptions.getSelector(),
            interval: 50,
            retries: Math.trunc(defaultOptions.getSelector() / 50),
            assertionTimeout: defaultOptions.getAssertion()
        }
        if (options?.timeout) {
            actualOptions.timeout = options.timeout;
        }
        if (options?.interval) {
            actualOptions.interval = options.interval;
        }
        if (options?.retries) {
            actualOptions.retries = options.retries;
        }
        if (options?.assertionTimeout) {
            actualOptions.assertionTimeout = options.assertionTimeout;
        }
        return actualOptions;
    }
}

export const methodOptions = new Options();




