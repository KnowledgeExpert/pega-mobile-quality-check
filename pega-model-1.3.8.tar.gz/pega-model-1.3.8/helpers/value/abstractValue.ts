import {Value} from './value';

export abstract class AbstractValue implements Value {

    private readonly key: string;
    private readonly value: string;

    constructor(key: string, value: string) {
        this.key = key;
        this.value = value;
    }

    get(): string {
        return this.value;
    }

    getAsBoolean(): boolean {
        return (this.get() === 'true');
    }

    getAsNumber(): number {
        return (Number(this.get()));
    }

    describe(): string {
        return this.key;
    }

}