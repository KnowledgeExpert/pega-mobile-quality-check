import {AbstractValue} from './abstractValue';

export class KeyValuePair extends AbstractValue {
    public toString(): string {
        return this.describe();
    }
}

export function keyValuePair(key: string, value: string): KeyValuePair {
    return new KeyValuePair(key, value);
}