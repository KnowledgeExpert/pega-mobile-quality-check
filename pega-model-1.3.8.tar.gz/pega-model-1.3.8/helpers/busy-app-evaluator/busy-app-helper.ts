/* eslint-disable @typescript-eslint/ban-ts-comment */
import {Controller, TerminalReporterOptionsBypass, logger} from 'test-maker';

type EvaluationResult = { isAppBusy: boolean; log: string; error?: Error };

export const evaluateIfAppIsBusy = async (I: Controller) => {
    const results: EvaluationResult[] = await I.evalInAllFrames({
        fn: evaluateIfAppIsBusyHelper,
        onlyMainFrames: true,
        breakOnFirstError: false,
        breakOnFirstResult: true,
    });
    const result = results.find((result) => result !== undefined);
    if (!result) {
        const currentUrl = await I.evalInCurrentWindowMainFrame(() => {
            console.log(`Current location href `, window.location.href);
            return window.location.href;

        });
        const log = `Not in Pega app (current URL: '${currentUrl}')`;
        return {isAppBusy: false, log};
    }
    return result;
};

const evaluateIfAppIsBusyHelper = (): EvaluationResult => {
    try {
        // @ts-ignore
        window.statetrackerSelector =
            // @ts-ignore
            window.statetrackerSelector || window.top.document.querySelector('.document-statetracker');
        // @ts-ignore
        if (!window.statetrackerSelector) {
            // @ts-ignore
            if (window.pega) {
                const log = `We are inside a Pega application, but statustracker is not available. Make sure it is enabled in Pega rules`;
                return {isAppBusy: false, log};
            }
            const log = `Data state busy status is not available`;
            return {isAppBusy: false, log};
        } else {
            // @ts-ignore
            const dataStateBusyStatus = window.statetrackerSelector.getAttribute('data-state-busy-status');
            const isAppBusy = dataStateBusyStatus === 'busy';
            const log = `Data state busy status is '${dataStateBusyStatus}'`;
            return {isAppBusy, log};
        }
    } catch (error) {
        const log = `An error occurred in the client while retrieving Pega state tracker: ${error.message}`;
        console.log(log);
        console.log(`Error message in the catch `, error.message);
        if (error === undefined) {
            error = new Error(`There is no iframe Selector available`)
        }
        return {isAppBusy: true, log, error};
    }
};

export const bypassLogging = async ({info}: TerminalReporterOptionsBypass) => {
    return !!info.inAppBusyCondition;
};
