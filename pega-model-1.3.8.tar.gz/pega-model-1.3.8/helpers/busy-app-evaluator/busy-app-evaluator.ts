/* eslint-disable @typescript-eslint/ban-ts-comment */
import { Controller, RetryOptions, TestRunInfo, logger } from 'test-maker';
import { evaluateIfAppIsBusy } from './busy-app-helper';
import { isWarnMessage } from './error-message-helper';
import {AdapterType} from './adapter-type';

export const isAppBusyEvaluator: {
    condition: (I: Controller, runInfo: TestRunInfo) => Promise<boolean>;
    retry?: RetryOptions;
    runBefore: {
        controllerActions: boolean;
        selectorActions: boolean;
        assertionActions: boolean;
    };
} = {
    condition: async (I: Controller, runInfo: TestRunInfo) => {
        if (runInfo.adapter.name === AdapterType.UNIT) {
            return false;
        }
        try {
            const { isAppBusy, log, error } = await evaluateIfAppIsBusy(I);
            if (error) {
                await logger.error(`[statetracker] ${log}`);
                await logger.error(error);
            } else {
                await logger.debug(`[statetracker] ${log}`);
            }
            return isAppBusy;
        } catch (error) {
            const errorMsg = error.message;
            const log = `[statetracker] An error occured while waiting for Pega state tracker not to be busy, cause: '${errorMsg}'`;
            const details = `[statetracker] Feature: '${runInfo.feature?.name}', scenario: '${runInfo.scenario?.name}', step: '${runInfo.step?.name}'`;
            if (isWarnMessage(errorMsg)) {
                await logger.warn(log);
                await logger.warn(details);
            } else {
                await logger.error(log);
                await logger.error(details);
                await logger.error(error);
            }
            return true;
        }
    },
    retry: {
        interval: 10,
        timeout: 60000,
        retryMessage: 'Waiting for Pega state tracker not to be busy',
    },
    runBefore: {
        controllerActions: true,
        selectorActions: true,
        assertionActions: true,
    },
};
