// Copyright 2018 Knowledge Expert SA
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

export class CustomDate {

    private readonly date: Date;
    private readonly monthNames = [null, "Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];

    constructor(date: Date) {
        this.date = date;
    }

    get day(): string {
        const day = this.date.getDate();
         return day < 10 ? `0${day}` : `${day}`;
        //return `${day}`;
    }

    get month(): string {
        const month = this.date.getMonth() + 1;
        return month < 10 ? `0${month}` : `${month}`;
        //return `${month}`;
    }

    get year(): string {
        return `${this.date.getFullYear()}`;
    }

    get hour(): string {
        const hour = this.date.getHours();
        return hour < 10 ? `0${hour}` : `${hour}`;
    }

    get minutes(): string {
        const minutes = this.date.getMinutes();
        return minutes < 10 ? `0${minutes}` : `${minutes}`;
    }

    minusYears(years: number): CustomDate {
        return new CustomDate(CustomDate.buildDate(this.date, {year: -years}));
    }

    plusYears(years: number): CustomDate {
        return new CustomDate(CustomDate.buildDate(this.date, {year: years}));
    }

    minusMonths(months: number): CustomDate {
        return new CustomDate(CustomDate.buildDate(this.date, {month: -months}));
    }

    plusMonths(months: number): CustomDate {
        return new CustomDate(CustomDate.buildDate(this.date, {month: months}));
    }

    minusDays(days: number): CustomDate {
        return new CustomDate(CustomDate.buildDate(this.date, {days: -days}));
    }

    plusDays(days: number): CustomDate {
        return new CustomDate(CustomDate.buildDate(this.date, {days: days}));
    }

    plusMinutes(minutes: number): CustomDate {
        return new CustomDate(CustomDate.buildDate(this.date, {minutes: minutes}));
    }

    minusMinutes(minutes: number): CustomDate {
        return new CustomDate(CustomDate.buildDate(this.date, {minutes: -minutes}));
    }

    plusHours(hours: number): CustomDate {
        return new CustomDate(CustomDate.buildDate(this.date, {hour: hours}));
    }

    minusHours(hours: number): CustomDate {
        return new CustomDate(CustomDate.buildDate(this.date, {hour: -hours}));
    }


    equals(customDate: CustomDate): boolean {
        return this.compareTo(customDate) === 0;
    }

    isBeforeThan(customDate: CustomDate): boolean {
        return this.compareTo(customDate) === -1;
    }

    isAfterThan(customDate: CustomDate): boolean {
        return this.compareTo(customDate) === 1;
    }

    toString(separator = '.', order = ['m', 'd', 'y']): string {
        return order.map(it => {
            return  it.charAt(0) == ('d') ? this.day :
                it.charAt(0) == ('m') ? this.month :
                    it.charAt(0) == ('M') ? this.monthNames[parseInt(this.month)] :
                        this.year;
        }).join(separator);
    }

    dateWithTimeToString(separator = '/', order = ['m', 'd', 'y', 'h', 'min']): string {
        return order.map(it => {
            return  it.charAt(0) == ('d') ? this.day :
                it.charAt(0) == ('m') ? this.month :
                    it.charAt(0) == ('M') ? this.monthNames[parseInt(this.month)] :
                        this.year;
        }).join(separator) + ` ${this.hour}:${this.minutes}`;
    }

    toStringBySlash(): string {
        return this.toString('/');
    }

    private compareTo(customDate: CustomDate): number {
        if (this.year > customDate.year) {
            return 1;
        } else if (this.year < customDate.year) {
            return -1;
        }

        if (this.month > customDate.month) {
            return 1;
        } else if (this.month < customDate.month) {
            return -1;
        }

        if (this.day > customDate.day) {
            return 1;
        } else if (this.day < customDate.day) {
            return -1;
        }

        return 0;
    }

    private static buildDate(fromDate: Date, options?: { days?: number, month?: number, year?: number, hour?: number, minutes?: number }): Date {
        const result = new Date(fromDate.toString());
        if (options.days) {
            result.setDate(fromDate.getDate() + options.days);
        }
        if (options.month) {
            result.setMonth(fromDate.getMonth() + options.month);
        }
        if (options.year) {
            result.setFullYear(fromDate.getFullYear() + options.year);
        }
        if (options.hour) {
            result.setHours(fromDate.getHours() + options.hour);
        }
        if (options.minutes) {
            result.setMinutes(fromDate.getMinutes() + options.minutes);
        }
        return result;
    }

}

export function forCurrentDate(): CustomDate {
    return new CustomDate(new Date());
}

export function today() {
    return forCurrentDate();
}

export function forDate(date: Date): CustomDate {
    return new CustomDate(date);
}

export function dateFrom(date: string, delimiter = ' ', order = ['d', 'm', 'y']) {
    const chunks = date.toLowerCase().split(delimiter);
    const day = chunks[order.indexOf('d')];
    const month = chunks[order.indexOf('m')];
    const year = chunks[order.indexOf('y')];
    return forDate(new Date(`${month} ${day} ${year}`));
}
