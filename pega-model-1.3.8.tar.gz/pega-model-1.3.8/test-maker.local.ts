import {Configuration, reporters, mergeAndConcat, I, Selector} from "test-maker";
import {common, operatorsManager} from './test-maker.common';

// @ts-ignore
const local = {
    //clients: ['edge'],
    source: [`./src/specs/pegalab-end-to-end-spec.ts`],
    //source: [`./src/specs/contract-spec.ts`, `./src/specs/new-demo-spec.ts`],
    runner: {
        parallel: 1,
        liveMode: false,
        keepClientOpen: false,
        clients: [{name: 'chrome', args: ['--window size=1680,1050']}]
    },
    extra: {
        env: {
            name: 'dev',
        },
        operatorsManager,
    },
    hooks: {
        beforeEachFeature: async (I, runInfo) => {
        },
        beforeEachScenario: async (I, runInfo) => {
            const name = runInfo.configuration.extra.env.name;
            console.log('Current environment=' + name);
            console.log('beforeEachScenario');
        }
    }

} as Configuration;

export default mergeAndConcat(common, local);
